library(e1071) 
library(GGally)
library(ggplot2)


data <- read.csv("E:/AIUB/11th semester/Data Science/Final/Lab/Assignment/lung_disease_data.csv", header = TRUE, sep = ",")
data


data$Gender[data$Gender == ""] <- NA
data$Smoking.Status[data$Smoking.Status == ""] <- NA
data$Disease.Type[data$Disease.Type == ""] <- NA
data$Treatment.Type[data$Treatment.Type == ""] <- NA
data$Recovered[data$Recovered == ""] <- NA
data$Age[is.na(data$Age)] <- mean(data$Age, na.rm = TRUE)
data$Lung.Capacity[is.na(data$Lung.Capacity)] <- mean(data$Lung.Capacity, na.rm = TRUE)
data$Hospital.Visits[is.na(data$Hospital.Visits)] <- mean(data$Hospital.Visits, na.rm = TRUE)


data$Age <- as.numeric(data$Age)
data$Lung.Capacity <- as.numeric(data$Lung.Capacity)
data$Hospital.Visits <- as.numeric(data$Hospital.Visits)



lung_capacity <- na.omit(data$Lung.Capacity)
mean_lung <- mean(lung_capacity)
median_lung <- median(lung_capacity)
mode_lung <- as.numeric(names(sort(table(lung_capacity), decreasing = TRUE)[1]))
skewness_lung <- skewness(lung_capacity)


x_range <- range(lung_capacity, na.rm = TRUE)
y_max <- max(hist(lung_capacity, plot = FALSE)$counts)

hist(lung_capacity, 
     main = "Histogram of Lung Capacity", 
     xlab = "Lung Capacity (liters)", 
     ylab = "Frequency of Patients", 
     col = "#87CEEB",  
     border = "black",  
     breaks = 15)
abline(v = mean_lung, col = "#004225", lty = 1, lwd = 2)  
abline(v = median_lung, col = "#8E1616", lty = 2, lwd = 2)  
abline(v = mode_lung, col = "#FFE31A", lty = 3, lwd = 2)  


text(x = x_range[2] - (x_range[2] - x_range[1]) * 0.05, y = y_max * 0.3, 
     labels = paste("Mean =", round(mean_lung, 2), "\nMedian =", round(median_lung, 2), 
                    "\nMode =", round(mode_lung, 2), "\nSkewness =", round(skewness_lung, 2)), 
     col = "black", adj = 1, cex = 0.9)





x <- seq(min(lung_capacity), max(lung_capacity), length = 100)
fit <- dnorm(x, mean = mean_lung, sd = sd(lung_capacity))
plot(x, fit, 
     type = "l", 
     main = "Bell Curve Approximation of Lung Capacity", 
     xlab = "Lung Capacity (liters)", 
     ylab = "Density", 
     col = "#ADD8E6", 
     lwd = 2)
polygon(c(min(x), x, max(x)), c(0, fit, 0), col = rgb(65/255, 105/255, 225/255, 0.4))  
text(mean_lung, max(fit) * 0.9, paste("Skewness =", round(skewness_lung, 2)), pos = 4, col = "black")





barplot(table(data$Disease.Type), 
        main = "Bar Graph of Disease Types", 
        xlab = "Disease Type", 
        ylab = "Number of Patients", 
        col = "#ADD8E6",  
        border = "black",  
        las = 2)




boxplot(lung_capacity, 
        main = "Box Plot of Lung Capacity", 
        xlab = "Lung Capacity (liters)", 
        ylab = "", 
        col = "#B0E0E6",  
        border = "black",  
        horizontal = TRUE)





scatter_data <- data[complete.cases(data[, c("Age", "Lung.Capacity", "Hospital.Visits")]), ]


ggplot(scatter_data, aes(x = Age, y = Lung.Capacity, size = Hospital.Visits, color = Hospital.Visits)) +
  geom_point(alpha = 0.6) +
  scale_color_gradient2(low = "#ECE852", mid = "#FB4141", high = "#5CB338", 
                        midpoint = mean(scatter_data$Hospital.Visits, na.rm = TRUE)) +
  scale_size_continuous(range = c(2, 8)) +
  labs(title = "Scatter Plot: Age vs Lung Capacity with Hospital Visits",
       x = "Age",
       y = "Lung Capacity (liters)",
       size = "Hospital Visits",
       color = "Hospital Visits") +
  theme_minimal()





ggplot(data, aes(x = Gender, y = Lung.Capacity, fill = Gender)) + 
  geom_violin() + 
  scale_fill_manual(values = c("Female" = "#CD5656", "Male" = "#4682B4")) +  
  labs(title = "Violin Plot: Lung Capacity by Gender", 
       x = "Gender", 
       y = "Lung Capacity (liters)") + 
  theme_minimal()

