data <- read.csv("E:/AIUB/11th semester/Data Science/Final/Lab/Assignment/lung_disease_data.csv", header = TRUE, sep = ",")
data

data$Gender[data$Gender == ""] <- NA
colSums(is.na(data))

data$Smoking.Status[data$Smoking.Status == ""] <- NA
colSums(is.na(data))

data$Disease.Type[data$Disease.Type == ""] <- NA
colSums(is.na(data))

data$Treatment.Type[data$Treatment.Type == ""] <- NA
colSums(is.na(data))

data$Recovered[data$Recovered == ""] <- NA
colSums(is.na(data))



age_lung_cor <- cor(data$Age, data$Lung.Capacity, method = "pearson", use = "complete.obs")
cat("Age vs Lung Capacity:", round(age_lung_cor, 4), "\n")

lung_hvisit_pearson <- cor(data$Lung.Capacity, data$Hospital.Visits, method = "pearson", use = "complete.obs")
cat("Lung Capacity vs Hospital Visits:", round(lung_hvisit_pearson, 4), "\n")


disease_recovered <- chisq.test(table(data$Disease.Type, data$Recovered))
print(disease_recovered)

treatment_recovered <- chisq.test(table(data$Treatment.Type, data$Recovered))
print(treatment_recovered)


lung_gender <- aov(Lung.Capacity ~ Gender, data = data)
p_value_lung_gender <- summary(lung_gender)[[1]]$`Pr(>F)`[1]
cat("p-value:", round(p_value_lung_gender, 4), "\n")

hvisit_treatment <- aov(Hospital.Visits ~ Treatment.Type, data = data)
p_value_hvisit_treatment <- summary(hvisit_treatment)[[1]]$`Pr(>F)`[1]
cat("p-value:", round(p_value_hvisit_treatment, 4), "\n")



data$Smoking.Status <- as.factor(data$Smoking.Status)
data$Smoking.Status <- as.numeric(data$Smoking.Status)

smoking_hvisit <- cor(data$Smoking.Status, data$Hospital.Visits, method = "kendall", use = "complete.obs")
cat("Smoking vs Hospital Visits:", round(smoking_hvisit, 4), "\n")





