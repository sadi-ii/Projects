package candidates;

public abstract class Candidates {
	Candidates(){}
	
	public abstract String getCandidateName();
}
