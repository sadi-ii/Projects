package candidates;



public class Bnp extends Candidates{
	private String candidateName;
	public Bnp(String candidateName){
		this.candidateName = candidateName;
	}

	public String getCandidateName()
	{
		return this.candidateName;
	}
}