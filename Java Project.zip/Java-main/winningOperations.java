package candidates;

public interface winningOperations {
	public void addAwamiLeague(AwamiLeague awami);
	public void addBnp(Bnp bn);
	public void addNationalParty(NationalParty nation);
	public void showWinner();
}
