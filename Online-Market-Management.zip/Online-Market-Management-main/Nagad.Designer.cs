﻿namespace OnlineMarketManagmnetSystem
{
    partial class Nagad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nagad));
            nbuttonBkashBack = new Guna.UI2.WinForms.Guna2Button();
            nbuttonBkashCancle = new Guna.UI2.WinForms.Guna2Button();
            nbuttonBkashEnter = new Guna.UI2.WinForms.Guna2Button();
            nphone = new Guna.UI2.WinForms.Guna2TextBox();
            picturenone = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // nbuttonBkashBack
            // 
            nbuttonBkashBack.BorderColor = Color.Transparent;
            nbuttonBkashBack.CustomizableEdges = customizableEdges9;
            nbuttonBkashBack.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashBack.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashBack.FillColor = Color.LightSkyBlue;
            nbuttonBkashBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashBack.ForeColor = Color.White;
            nbuttonBkashBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashBack.Location = new Point(68, 408);
            nbuttonBkashBack.Name = "nbuttonBkashBack";
            nbuttonBkashBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            nbuttonBkashBack.Size = new Size(80, 26);
            nbuttonBkashBack.TabIndex = 30;
            nbuttonBkashBack.Text = "Back";
            nbuttonBkashBack.Click += nbuttonBkashBack_Click;
            // 
            // nbuttonBkashCancle
            // 
            nbuttonBkashCancle.BorderColor = Color.Transparent;
            nbuttonBkashCancle.CustomizableEdges = customizableEdges11;
            nbuttonBkashCancle.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashCancle.FillColor = Color.Red;
            nbuttonBkashCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashCancle.ForeColor = Color.White;
            nbuttonBkashCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashCancle.Location = new Point(679, 245);
            nbuttonBkashCancle.Name = "nbuttonBkashCancle";
            nbuttonBkashCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            nbuttonBkashCancle.Size = new Size(84, 26);
            nbuttonBkashCancle.TabIndex = 29;
            nbuttonBkashCancle.Text = "Cancle";
            nbuttonBkashCancle.Click += nbuttonBkashCancle_Click;
            // 
            // nbuttonBkashEnter
            // 
            nbuttonBkashEnter.BorderColor = Color.Transparent;
            nbuttonBkashEnter.CustomizableEdges = customizableEdges13;
            nbuttonBkashEnter.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashEnter.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashEnter.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashEnter.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashEnter.FillColor = Color.SpringGreen;
            nbuttonBkashEnter.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashEnter.ForeColor = Color.White;
            nbuttonBkashEnter.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashEnter.Location = new Point(526, 245);
            nbuttonBkashEnter.Name = "nbuttonBkashEnter";
            nbuttonBkashEnter.ShadowDecoration.CustomizableEdges = customizableEdges14;
            nbuttonBkashEnter.Size = new Size(80, 26);
            nbuttonBkashEnter.TabIndex = 28;
            nbuttonBkashEnter.Text = "Enter";
            nbuttonBkashEnter.Click += nbuttonBkashEnter_Click;
            // 
            // nphone
            // 
            nphone.BorderThickness = 0;
            nphone.CustomizableEdges = customizableEdges15;
            nphone.DefaultText = "";
            nphone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            nphone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            nphone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            nphone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            nphone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            nphone.Font = new Font("Segoe UI", 9F);
            nphone.ForeColor = Color.Blue;
            nphone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            nphone.Location = new Point(526, 137);
            nphone.Name = "nphone";
            nphone.PasswordChar = '\0';
            nphone.PlaceholderForeColor = Color.Blue;
            nphone.PlaceholderText = "      +8801---------";
            nphone.SelectedText = "";
            nphone.ShadowDecoration.CustomizableEdges = customizableEdges16;
            nphone.ShadowDecoration.Enabled = true;
            nphone.Size = new Size(237, 26);
            nphone.TabIndex = 27;
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(54, 78);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(313, 265);
            picturenone.SizeMode = PictureBoxSizeMode.StretchImage;
            picturenone.TabIndex = 26;
            picturenone.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(426, 47);
            label1.Name = "label1";
            label1.Size = new Size(465, 37);
            label1.TabIndex = 25;
            label1.Text = "Enter Your Nagad Account Number";
            // 
            // Nagad
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSalmon;
            ClientSize = new Size(934, 481);
            Controls.Add(nbuttonBkashBack);
            Controls.Add(nbuttonBkashCancle);
            Controls.Add(nbuttonBkashEnter);
            Controls.Add(nphone);
            Controls.Add(picturenone);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Nagad";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Nagad";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button nbuttonBkashBack;
        private Guna.UI2.WinForms.Guna2Button nbuttonBkashCancle;
        private Guna.UI2.WinForms.Guna2Button nbuttonBkashEnter;
        private Guna.UI2.WinForms.Guna2TextBox nphone;
        private PictureBox picturenone;
        private Label label1;
    }
}