﻿namespace OnlineMarketManagmnetSystem
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            buttonProductSearch = new Guna.UI2.WinForms.Guna2Button();
            comboboxSearchCategory = new ComboBox();
            comboboxProductCategories = new ComboBox();
            txtProductPrice = new Guna.UI2.WinForms.Guna2TextBox();
            txtProductQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            DataGridViewProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            buttonProductUpdate = new Guna.UI2.WinForms.Guna2Button();
            buttonProductDelete = new Guna.UI2.WinForms.Guna2Button();
            label2 = new Label();
            buttonProductAdd = new Guna.UI2.WinForms.Guna2Button();
            txtProductName = new Guna.UI2.WinForms.Guna2TextBox();
            txtProductId = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox2 = new PictureBox();
            buttonProductLogout = new Guna.UI2.WinForms.Guna2Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            buttonProductCategories = new Guna.UI2.WinForms.Guna2Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewProduct).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(buttonProductSearch);
            panel1.Controls.Add(comboboxSearchCategory);
            panel1.Controls.Add(comboboxProductCategories);
            panel1.Controls.Add(txtProductPrice);
            panel1.Controls.Add(txtProductQuantity);
            panel1.Controls.Add(DataGridViewProduct);
            panel1.Controls.Add(buttonProductUpdate);
            panel1.Controls.Add(buttonProductDelete);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(buttonProductAdd);
            panel1.Controls.Add(txtProductName);
            panel1.Controls.Add(txtProductId);
            panel1.Location = new Point(147, 76);
            panel1.Name = "panel1";
            panel1.Size = new Size(787, 408);
            panel1.TabIndex = 27;
            // 
            // buttonProductSearch
            // 
            buttonProductSearch.BorderColor = Color.Transparent;
            buttonProductSearch.CustomizableEdges = customizableEdges1;
            buttonProductSearch.DisabledState.BorderColor = Color.DarkGray;
            buttonProductSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductSearch.FillColor = Color.MediumSpringGreen;
            buttonProductSearch.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductSearch.ForeColor = Color.White;
            buttonProductSearch.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductSearch.Location = new Point(691, 17);
            buttonProductSearch.Name = "buttonProductSearch";
            buttonProductSearch.ShadowDecoration.CustomizableEdges = customizableEdges2;
            buttonProductSearch.Size = new Size(93, 23);
            buttonProductSearch.TabIndex = 29;
            buttonProductSearch.Text = "SEARCH";
            buttonProductSearch.Click += buttonProductSearch_Click;
            // 
            // comboboxSearchCategory
            // 
            comboboxSearchCategory.BackColor = SystemColors.ButtonHighlight;
            comboboxSearchCategory.ForeColor = Color.Blue;
            comboboxSearchCategory.FormattingEnabled = true;
            comboboxSearchCategory.Location = new Point(481, 17);
            comboboxSearchCategory.Name = "comboboxSearchCategory";
            comboboxSearchCategory.Size = new Size(200, 23);
            comboboxSearchCategory.TabIndex = 28;
            comboboxSearchCategory.Text = "Select Category";
            comboboxSearchCategory.SelectedIndexChanged += comboboxSearchCategory_SelectedIndexChanged_1;
            // 
            // comboboxProductCategories
            // 
            comboboxProductCategories.BackColor = SystemColors.ButtonHighlight;
            comboboxProductCategories.ForeColor = Color.Blue;
            comboboxProductCategories.FormattingEnabled = true;
            comboboxProductCategories.Location = new Point(13, 258);
            comboboxProductCategories.Name = "comboboxProductCategories";
            comboboxProductCategories.Size = new Size(237, 23);
            comboboxProductCategories.TabIndex = 27;
            comboboxProductCategories.Text = "Select Category";
            // 
            // txtProductPrice
            // 
            txtProductPrice.BorderThickness = 0;
            txtProductPrice.CustomizableEdges = customizableEdges3;
            txtProductPrice.DefaultText = "";
            txtProductPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductPrice.Font = new Font("Segoe UI", 9F);
            txtProductPrice.ForeColor = Color.Blue;
            txtProductPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductPrice.Location = new Point(13, 213);
            txtProductPrice.Name = "txtProductPrice";
            txtProductPrice.PasswordChar = '\0';
            txtProductPrice.PlaceholderForeColor = Color.Blue;
            txtProductPrice.PlaceholderText = "Product Price";
            txtProductPrice.SelectedText = "";
            txtProductPrice.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtProductPrice.Size = new Size(237, 26);
            txtProductPrice.TabIndex = 26;
            // 
            // txtProductQuantity
            // 
            txtProductQuantity.BorderThickness = 0;
            txtProductQuantity.CustomizableEdges = customizableEdges5;
            txtProductQuantity.DefaultText = "";
            txtProductQuantity.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductQuantity.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductQuantity.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductQuantity.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductQuantity.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductQuantity.Font = new Font("Segoe UI", 9F);
            txtProductQuantity.ForeColor = Color.Blue;
            txtProductQuantity.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductQuantity.Location = new Point(13, 168);
            txtProductQuantity.Name = "txtProductQuantity";
            txtProductQuantity.PasswordChar = '\0';
            txtProductQuantity.PlaceholderForeColor = Color.Blue;
            txtProductQuantity.PlaceholderText = "Product Quantity";
            txtProductQuantity.SelectedText = "";
            txtProductQuantity.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtProductQuantity.Size = new Size(237, 26);
            txtProductQuantity.TabIndex = 25;
            // 
            // DataGridViewProduct
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            DataGridViewProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            DataGridViewProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            DataGridViewProduct.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            DataGridViewProduct.DefaultCellStyle = dataGridViewCellStyle3;
            DataGridViewProduct.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.Location = new Point(256, 46);
            DataGridViewProduct.Name = "DataGridViewProduct";
            DataGridViewProduct.RowHeadersVisible = false;
            DataGridViewProduct.Size = new Size(531, 362);
            DataGridViewProduct.TabIndex = 24;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            DataGridViewProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            DataGridViewProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            DataGridViewProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            DataGridViewProduct.ThemeStyle.HeaderStyle.Height = 30;
            DataGridViewProduct.ThemeStyle.ReadOnly = false;
            DataGridViewProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            DataGridViewProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewProduct.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            DataGridViewProduct.ThemeStyle.RowsStyle.Height = 25;
            DataGridViewProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // buttonProductUpdate
            // 
            buttonProductUpdate.BorderColor = Color.Transparent;
            buttonProductUpdate.CustomizableEdges = customizableEdges7;
            buttonProductUpdate.DisabledState.BorderColor = Color.DarkGray;
            buttonProductUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductUpdate.FillColor = Color.Cyan;
            buttonProductUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductUpdate.ForeColor = Color.White;
            buttonProductUpdate.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductUpdate.Location = new Point(99, 300);
            buttonProductUpdate.Name = "buttonProductUpdate";
            buttonProductUpdate.ShadowDecoration.CustomizableEdges = customizableEdges8;
            buttonProductUpdate.Size = new Size(93, 26);
            buttonProductUpdate.TabIndex = 23;
            buttonProductUpdate.Text = "UPDATE";
            buttonProductUpdate.Click += buttonProductUpdate_Click;
            // 
            // buttonProductDelete
            // 
            buttonProductDelete.BorderColor = Color.Transparent;
            buttonProductDelete.CustomizableEdges = customizableEdges9;
            buttonProductDelete.DisabledState.BorderColor = Color.DarkGray;
            buttonProductDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductDelete.FillColor = Color.Red;
            buttonProductDelete.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductDelete.ForeColor = Color.White;
            buttonProductDelete.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductDelete.Location = new Point(56, 367);
            buttonProductDelete.Name = "buttonProductDelete";
            buttonProductDelete.ShadowDecoration.CustomizableEdges = customizableEdges10;
            buttonProductDelete.Size = new Size(88, 26);
            buttonProductDelete.TabIndex = 22;
            buttonProductDelete.Text = "DELETE";
            buttonProductDelete.Click += buttonProductDelete_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.AntiqueWhite;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(232, 0);
            label2.Name = "label2";
            label2.Size = new Size(229, 32);
            label2.TabIndex = 12;
            label2.Text = "Product Management";
            // 
            // buttonProductAdd
            // 
            buttonProductAdd.BorderColor = Color.Transparent;
            buttonProductAdd.CustomizableEdges = customizableEdges11;
            buttonProductAdd.DisabledState.BorderColor = Color.DarkGray;
            buttonProductAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductAdd.FillColor = Color.RoyalBlue;
            buttonProductAdd.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductAdd.ForeColor = Color.White;
            buttonProductAdd.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductAdd.Location = new Point(13, 300);
            buttonProductAdd.Name = "buttonProductAdd";
            buttonProductAdd.ShadowDecoration.CustomizableEdges = customizableEdges12;
            buttonProductAdd.Size = new Size(80, 26);
            buttonProductAdd.TabIndex = 21;
            buttonProductAdd.Text = "ADD";
            buttonProductAdd.Click += buttonProductAdd_Click;
            // 
            // txtProductName
            // 
            txtProductName.BorderThickness = 0;
            txtProductName.CustomizableEdges = customizableEdges13;
            txtProductName.DefaultText = "";
            txtProductName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductName.Font = new Font("Segoe UI", 9F);
            txtProductName.ForeColor = Color.Blue;
            txtProductName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductName.Location = new Point(13, 123);
            txtProductName.Name = "txtProductName";
            txtProductName.PasswordChar = '\0';
            txtProductName.PlaceholderForeColor = Color.Blue;
            txtProductName.PlaceholderText = "Product Name";
            txtProductName.SelectedText = "";
            txtProductName.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtProductName.Size = new Size(237, 26);
            txtProductName.TabIndex = 19;
            // 
            // txtProductId
            // 
            txtProductId.BorderThickness = 0;
            txtProductId.CustomizableEdges = customizableEdges15;
            txtProductId.DefaultText = "";
            txtProductId.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductId.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductId.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductId.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductId.Font = new Font("Segoe UI", 9F);
            txtProductId.ForeColor = Color.Blue;
            txtProductId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductId.Location = new Point(13, 78);
            txtProductId.Name = "txtProductId";
            txtProductId.PasswordChar = '\0';
            txtProductId.PlaceholderForeColor = Color.Blue;
            txtProductId.PlaceholderText = "Product Id";
            txtProductId.SelectedText = "";
            txtProductId.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtProductId.ShadowDecoration.Enabled = true;
            txtProductId.Size = new Size(237, 26);
            txtProductId.TabIndex = 18;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(890, 1);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 34);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // buttonProductLogout
            // 
            buttonProductLogout.BorderColor = Color.Transparent;
            buttonProductLogout.CustomizableEdges = customizableEdges17;
            buttonProductLogout.DisabledState.BorderColor = Color.DarkGray;
            buttonProductLogout.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductLogout.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductLogout.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductLogout.FillColor = Color.Violet;
            buttonProductLogout.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductLogout.ForeColor = Color.White;
            buttonProductLogout.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductLogout.Location = new Point(13, 444);
            buttonProductLogout.Name = "buttonProductLogout";
            buttonProductLogout.ShadowDecoration.CustomizableEdges = customizableEdges18;
            buttonProductLogout.Size = new Size(108, 26);
            buttonProductLogout.TabIndex = 32;
            buttonProductLogout.Text = "LOGOUT";
            buttonProductLogout.Click += buttonProductLogout_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-7, 1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(148, 179);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 29;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.AntiqueWhite;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(255, 10);
            label1.Name = "label1";
            label1.Size = new Size(479, 39);
            label1.TabIndex = 28;
            label1.Text = "Online Market Management System";
            // 
            // buttonProductCategories
            // 
            buttonProductCategories.BorderColor = Color.Transparent;
            buttonProductCategories.CustomizableEdges = customizableEdges19;
            buttonProductCategories.DisabledState.BorderColor = Color.DarkGray;
            buttonProductCategories.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductCategories.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductCategories.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductCategories.FillColor = Color.LightBlue;
            buttonProductCategories.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductCategories.ForeColor = Color.White;
            buttonProductCategories.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductCategories.Location = new Point(4, 199);
            buttonProductCategories.Name = "buttonProductCategories";
            buttonProductCategories.ShadowDecoration.CustomizableEdges = customizableEdges20;
            buttonProductCategories.Size = new Size(117, 26);
            buttonProductCategories.TabIndex = 28;
            buttonProductCategories.Text = "Categories";
            buttonProductCategories.TextAlign = HorizontalAlignment.Left;
            buttonProductCategories.Click += buttonProductCategories_Click;
            // 
            // Product
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 481);
            Controls.Add(panel1);
            Controls.Add(buttonProductCategories);
            Controls.Add(pictureBox2);
            Controls.Add(buttonProductLogout);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Product";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Product";
            Load += Product_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewProduct).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridViewProduct;
        private Guna.UI2.WinForms.Guna2Button buttonProductUpdate;
        private Guna.UI2.WinForms.Guna2Button buttonProductDelete;
        private Guna.UI2.WinForms.Guna2Button buttonProductAdd;
        private Guna.UI2.WinForms.Guna2TextBox txtProductName;
        private Guna.UI2.WinForms.Guna2TextBox txtProductId;
        private Label label2;
        private PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2Button buttonProductLogout;
        private PictureBox pictureBox1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtProductPrice;
        private Guna.UI2.WinForms.Guna2TextBox txtProductQuantity;
        private ComboBox comboboxProductCategories;
        private Guna.UI2.WinForms.Guna2Button buttonProductCategories;
        private Guna.UI2.WinForms.Guna2Button buttonProductSearch;
        private ComboBox comboboxSearchCategory;
    }
}