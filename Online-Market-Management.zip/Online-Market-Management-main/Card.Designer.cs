﻿namespace OnlineMarketManagmnetSystem
{
    partial class Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Card));
            cbuttonBkashBack = new Guna.UI2.WinForms.Guna2Button();
            cbuttonBkashCancle = new Guna.UI2.WinForms.Guna2Button();
            cbuttonBkashEnter = new Guna.UI2.WinForms.Guna2Button();
            cphone = new Guna.UI2.WinForms.Guna2TextBox();
            picturenone = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // cbuttonBkashBack
            // 
            cbuttonBkashBack.BorderColor = Color.Transparent;
            cbuttonBkashBack.CustomizableEdges = customizableEdges9;
            cbuttonBkashBack.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashBack.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashBack.FillColor = Color.DodgerBlue;
            cbuttonBkashBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashBack.ForeColor = Color.White;
            cbuttonBkashBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashBack.Location = new Point(54, 408);
            cbuttonBkashBack.Name = "cbuttonBkashBack";
            cbuttonBkashBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            cbuttonBkashBack.Size = new Size(80, 26);
            cbuttonBkashBack.TabIndex = 30;
            cbuttonBkashBack.Text = "Back";
            cbuttonBkashBack.Click += cbuttonBkashBack_Click;
            // 
            // cbuttonBkashCancle
            // 
            cbuttonBkashCancle.BorderColor = Color.Transparent;
            cbuttonBkashCancle.CustomizableEdges = customizableEdges11;
            cbuttonBkashCancle.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashCancle.FillColor = Color.Red;
            cbuttonBkashCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashCancle.ForeColor = Color.White;
            cbuttonBkashCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashCancle.Location = new Point(679, 245);
            cbuttonBkashCancle.Name = "cbuttonBkashCancle";
            cbuttonBkashCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            cbuttonBkashCancle.Size = new Size(84, 26);
            cbuttonBkashCancle.TabIndex = 29;
            cbuttonBkashCancle.Text = "Cancle";
            cbuttonBkashCancle.Click += cbuttonBkashCancle_Click;
            // 
            // cbuttonBkashEnter
            // 
            cbuttonBkashEnter.BorderColor = Color.Transparent;
            cbuttonBkashEnter.CustomizableEdges = customizableEdges13;
            cbuttonBkashEnter.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashEnter.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashEnter.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashEnter.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashEnter.FillColor = Color.SpringGreen;
            cbuttonBkashEnter.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashEnter.ForeColor = Color.White;
            cbuttonBkashEnter.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashEnter.Location = new Point(526, 245);
            cbuttonBkashEnter.Name = "cbuttonBkashEnter";
            cbuttonBkashEnter.ShadowDecoration.CustomizableEdges = customizableEdges14;
            cbuttonBkashEnter.Size = new Size(80, 26);
            cbuttonBkashEnter.TabIndex = 28;
            cbuttonBkashEnter.Text = "Enter";
            cbuttonBkashEnter.Click += cbuttonBkashEnter_Click;
            // 
            // cphone
            // 
            cphone.BorderThickness = 0;
            cphone.CustomizableEdges = customizableEdges15;
            cphone.DefaultText = "";
            cphone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            cphone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            cphone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            cphone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            cphone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cphone.Font = new Font("Segoe UI", 9F);
            cphone.ForeColor = Color.Blue;
            cphone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            cphone.Location = new Point(526, 137);
            cphone.Name = "cphone";
            cphone.PasswordChar = '\0';
            cphone.PlaceholderForeColor = Color.Blue;
            cphone.PlaceholderText = "                   ----  ----  ----  ----";
            cphone.SelectedText = "";
            cphone.ShadowDecoration.CustomizableEdges = customizableEdges16;
            cphone.ShadowDecoration.Enabled = true;
            cphone.Size = new Size(237, 26);
            cphone.TabIndex = 27;
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(54, 78);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(368, 265);
            picturenone.SizeMode = PictureBoxSizeMode.Zoom;
            picturenone.TabIndex = 26;
            picturenone.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Cyan;
            label1.Location = new Point(482, 47);
            label1.Name = "label1";
            label1.Size = new Size(328, 37);
            label1.TabIndex = 25;
            label1.Text = "Enter Your Card Number";
            // 
            // Card
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(934, 481);
            Controls.Add(cbuttonBkashBack);
            Controls.Add(cbuttonBkashCancle);
            Controls.Add(cbuttonBkashEnter);
            Controls.Add(cphone);
            Controls.Add(picturenone);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Card";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Card";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button cbuttonBkashBack;
        private Guna.UI2.WinForms.Guna2Button cbuttonBkashCancle;
        private Guna.UI2.WinForms.Guna2Button cbuttonBkashEnter;
        private Guna.UI2.WinForms.Guna2TextBox cphone;
        private PictureBox picturenone;
        private Label label1;
    }
}