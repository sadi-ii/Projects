﻿namespace OnlineMarketManagmnetSystem
{
    partial class Notp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Notp));
            nbuttonBkashOtpBack = new Guna.UI2.WinForms.Guna2Button();
            nbuttonBkashotpCancle = new Guna.UI2.WinForms.Guna2Button();
            nbuttonBkashotpConfirm = new Guna.UI2.WinForms.Guna2Button();
            n = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // nbuttonBkashOtpBack
            // 
            nbuttonBkashOtpBack.BorderColor = Color.Transparent;
            nbuttonBkashOtpBack.CustomizableEdges = customizableEdges9;
            nbuttonBkashOtpBack.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashOtpBack.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashOtpBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashOtpBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashOtpBack.FillColor = Color.LightSkyBlue;
            nbuttonBkashOtpBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashOtpBack.ForeColor = Color.White;
            nbuttonBkashOtpBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashOtpBack.Location = new Point(92, 413);
            nbuttonBkashOtpBack.Name = "nbuttonBkashOtpBack";
            nbuttonBkashOtpBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            nbuttonBkashOtpBack.Size = new Size(80, 26);
            nbuttonBkashOtpBack.TabIndex = 36;
            nbuttonBkashOtpBack.Text = "Back";
            nbuttonBkashOtpBack.Click += nbuttonBkashOtpBack_Click;
            // 
            // nbuttonBkashotpCancle
            // 
            nbuttonBkashotpCancle.BorderColor = Color.Transparent;
            nbuttonBkashotpCancle.CustomizableEdges = customizableEdges11;
            nbuttonBkashotpCancle.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashotpCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashotpCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashotpCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashotpCancle.FillColor = Color.Red;
            nbuttonBkashotpCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashotpCancle.ForeColor = Color.White;
            nbuttonBkashotpCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashotpCancle.Location = new Point(703, 250);
            nbuttonBkashotpCancle.Name = "nbuttonBkashotpCancle";
            nbuttonBkashotpCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            nbuttonBkashotpCancle.Size = new Size(84, 26);
            nbuttonBkashotpCancle.TabIndex = 35;
            nbuttonBkashotpCancle.Text = "Cancle";
            nbuttonBkashotpCancle.Click += nbuttonBkashotpCancle_Click;
            // 
            // nbuttonBkashotpConfirm
            // 
            nbuttonBkashotpConfirm.BorderColor = Color.Transparent;
            nbuttonBkashotpConfirm.CustomizableEdges = customizableEdges13;
            nbuttonBkashotpConfirm.DisabledState.BorderColor = Color.DarkGray;
            nbuttonBkashotpConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            nbuttonBkashotpConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nbuttonBkashotpConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nbuttonBkashotpConfirm.FillColor = Color.FromArgb(128, 128, 255);
            nbuttonBkashotpConfirm.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nbuttonBkashotpConfirm.ForeColor = Color.White;
            nbuttonBkashotpConfirm.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            nbuttonBkashotpConfirm.Location = new Point(550, 250);
            nbuttonBkashotpConfirm.Name = "nbuttonBkashotpConfirm";
            nbuttonBkashotpConfirm.ShadowDecoration.CustomizableEdges = customizableEdges14;
            nbuttonBkashotpConfirm.Size = new Size(101, 26);
            nbuttonBkashotpConfirm.TabIndex = 34;
            nbuttonBkashotpConfirm.Text = "Comfirm";
            nbuttonBkashotpConfirm.Click += nbuttonBkashotpConfirm_Click;
            // 
            // n
            // 
            n.BorderThickness = 0;
            n.CustomizableEdges = customizableEdges15;
            n.DefaultText = "";
            n.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            n.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            n.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            n.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            n.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            n.Font = new Font("Segoe UI", 9F);
            n.ForeColor = Color.Blue;
            n.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            n.Location = new Point(550, 142);
            n.Name = "n";
            n.PasswordChar = '\0';
            n.PlaceholderForeColor = Color.Blue;
            n.PlaceholderText = "      ---------";
            n.SelectedText = "";
            n.ShadowDecoration.CustomizableEdges = customizableEdges16;
            n.ShadowDecoration.Enabled = true;
            n.Size = new Size(237, 26);
            n.TabIndex = 33;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(78, 83);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(313, 265);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 32;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MediumSeaGreen;
            label1.Location = new Point(550, 62);
            label1.Name = "label1";
            label1.Size = new Size(143, 37);
            label1.TabIndex = 31;
            label1.Text = "Enter OTP";
            // 
            // Notp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSalmon;
            ClientSize = new Size(934, 481);
            Controls.Add(nbuttonBkashOtpBack);
            Controls.Add(nbuttonBkashotpCancle);
            Controls.Add(nbuttonBkashotpConfirm);
            Controls.Add(n);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Notp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Notp";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button nbuttonBkashOtpBack;
        private Guna.UI2.WinForms.Guna2Button nbuttonBkashotpCancle;
        private Guna.UI2.WinForms.Guna2Button nbuttonBkashotpConfirm;
        private Guna.UI2.WinForms.Guna2TextBox n;
        private PictureBox pictureBox1;
        private Label label1;
    }
}