﻿namespace OnlineMarketManagmnetSystem
{
    partial class AdminView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminView));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            DataGridViewCategories = new Guna.UI2.WinForms.Guna2DataGridView();
            buttonCategoriesUpdate = new Guna.UI2.WinForms.Guna2Button();
            buttonCategoriesDelete = new Guna.UI2.WinForms.Guna2Button();
            buttonCategoriesAdd = new Guna.UI2.WinForms.Guna2Button();
            txtCategoriesDescribtion = new Guna.UI2.WinForms.Guna2TextBox();
            txtCategoriesName = new Guna.UI2.WinForms.Guna2TextBox();
            txtCategoriesId = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            buttonCategoriesLogout = new Guna.UI2.WinForms.Guna2Button();
            buttonProductCategories = new Guna.UI2.WinForms.Guna2Button();
            buttonSellingDetails = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewCategories).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(889, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 34);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 9;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(DataGridViewCategories);
            panel1.Controls.Add(buttonCategoriesUpdate);
            panel1.Controls.Add(buttonCategoriesDelete);
            panel1.Controls.Add(buttonCategoriesAdd);
            panel1.Controls.Add(txtCategoriesDescribtion);
            panel1.Controls.Add(txtCategoriesName);
            panel1.Controls.Add(txtCategoriesId);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(146, 75);
            panel1.Name = "panel1";
            panel1.Size = new Size(787, 408);
            panel1.TabIndex = 10;
            panel1.Paint += panel1_Paint;
            // 
            // DataGridViewCategories
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            DataGridViewCategories.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            DataGridViewCategories.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            DataGridViewCategories.ColumnHeadersHeight = 30;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            DataGridViewCategories.DefaultCellStyle = dataGridViewCellStyle3;
            DataGridViewCategories.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewCategories.Location = new Point(256, 46);
            DataGridViewCategories.Name = "DataGridViewCategories";
            DataGridViewCategories.RowHeadersVisible = false;
            DataGridViewCategories.Size = new Size(531, 362);
            DataGridViewCategories.TabIndex = 24;
            DataGridViewCategories.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            DataGridViewCategories.ThemeStyle.AlternatingRowsStyle.Font = null;
            DataGridViewCategories.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            DataGridViewCategories.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            DataGridViewCategories.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            DataGridViewCategories.ThemeStyle.BackColor = Color.White;
            DataGridViewCategories.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewCategories.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            DataGridViewCategories.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            DataGridViewCategories.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewCategories.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            DataGridViewCategories.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            DataGridViewCategories.ThemeStyle.HeaderStyle.Height = 30;
            DataGridViewCategories.ThemeStyle.ReadOnly = false;
            DataGridViewCategories.ThemeStyle.RowsStyle.BackColor = Color.White;
            DataGridViewCategories.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            DataGridViewCategories.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewCategories.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            DataGridViewCategories.ThemeStyle.RowsStyle.Height = 25;
            DataGridViewCategories.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            DataGridViewCategories.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            DataGridViewCategories.CellContentClick += DataGridViewCategories_CellContentClick;
            // 
            // buttonCategoriesUpdate
            // 
            buttonCategoriesUpdate.BorderColor = Color.Transparent;
            buttonCategoriesUpdate.CustomizableEdges = customizableEdges1;
            buttonCategoriesUpdate.DisabledState.BorderColor = Color.DarkGray;
            buttonCategoriesUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonCategoriesUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonCategoriesUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonCategoriesUpdate.FillColor = Color.Cyan;
            buttonCategoriesUpdate.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCategoriesUpdate.ForeColor = Color.White;
            buttonCategoriesUpdate.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonCategoriesUpdate.Location = new Point(99, 274);
            buttonCategoriesUpdate.Name = "buttonCategoriesUpdate";
            buttonCategoriesUpdate.ShadowDecoration.CustomizableEdges = customizableEdges2;
            buttonCategoriesUpdate.Size = new Size(93, 26);
            buttonCategoriesUpdate.TabIndex = 23;
            buttonCategoriesUpdate.Text = "UPDATE";
            buttonCategoriesUpdate.Click += buttonCategoriesUpdate_Click;
            // 
            // buttonCategoriesDelete
            // 
            buttonCategoriesDelete.BorderColor = Color.Transparent;
            buttonCategoriesDelete.CustomizableEdges = customizableEdges3;
            buttonCategoriesDelete.DisabledState.BorderColor = Color.DarkGray;
            buttonCategoriesDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonCategoriesDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonCategoriesDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonCategoriesDelete.FillColor = Color.Red;
            buttonCategoriesDelete.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCategoriesDelete.ForeColor = Color.White;
            buttonCategoriesDelete.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonCategoriesDelete.Location = new Point(56, 341);
            buttonCategoriesDelete.Name = "buttonCategoriesDelete";
            buttonCategoriesDelete.ShadowDecoration.CustomizableEdges = customizableEdges4;
            buttonCategoriesDelete.Size = new Size(88, 26);
            buttonCategoriesDelete.TabIndex = 22;
            buttonCategoriesDelete.Text = "DELETE";
            buttonCategoriesDelete.Click += buttonCategoriesDelete_Click;
            // 
            // buttonCategoriesAdd
            // 
            buttonCategoriesAdd.BorderColor = Color.Transparent;
            buttonCategoriesAdd.CustomizableEdges = customizableEdges5;
            buttonCategoriesAdd.DisabledState.BorderColor = Color.DarkGray;
            buttonCategoriesAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonCategoriesAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonCategoriesAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonCategoriesAdd.FillColor = Color.RoyalBlue;
            buttonCategoriesAdd.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCategoriesAdd.ForeColor = Color.White;
            buttonCategoriesAdd.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonCategoriesAdd.Location = new Point(13, 274);
            buttonCategoriesAdd.Name = "buttonCategoriesAdd";
            buttonCategoriesAdd.ShadowDecoration.CustomizableEdges = customizableEdges6;
            buttonCategoriesAdd.Size = new Size(80, 26);
            buttonCategoriesAdd.TabIndex = 21;
            buttonCategoriesAdd.Text = "ADD";
            buttonCategoriesAdd.Click += buttonCategoriesAdd_Click;
            // 
            // txtCategoriesDescribtion
            // 
            txtCategoriesDescribtion.BorderThickness = 0;
            txtCategoriesDescribtion.CustomizableEdges = customizableEdges7;
            txtCategoriesDescribtion.DefaultText = "";
            txtCategoriesDescribtion.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoriesDescribtion.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoriesDescribtion.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesDescribtion.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesDescribtion.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesDescribtion.Font = new Font("Segoe UI", 9F);
            txtCategoriesDescribtion.ForeColor = Color.Blue;
            txtCategoriesDescribtion.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesDescribtion.Location = new Point(13, 189);
            txtCategoriesDescribtion.Name = "txtCategoriesDescribtion";
            txtCategoriesDescribtion.PasswordChar = '\0';
            txtCategoriesDescribtion.PlaceholderText = "Categories Describtion";
            txtCategoriesDescribtion.SelectedText = "";
            txtCategoriesDescribtion.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtCategoriesDescribtion.Size = new Size(237, 26);
            txtCategoriesDescribtion.TabIndex = 20;
            // 
            // txtCategoriesName
            // 
            txtCategoriesName.BorderThickness = 0;
            txtCategoriesName.CustomizableEdges = customizableEdges9;
            txtCategoriesName.DefaultText = "";
            txtCategoriesName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoriesName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoriesName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesName.Font = new Font("Segoe UI", 9F);
            txtCategoriesName.ForeColor = Color.Blue;
            txtCategoriesName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesName.Location = new Point(13, 131);
            txtCategoriesName.Name = "txtCategoriesName";
            txtCategoriesName.PasswordChar = '\0';
            txtCategoriesName.PlaceholderText = "Categories Name";
            txtCategoriesName.SelectedText = "";
            txtCategoriesName.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtCategoriesName.Size = new Size(237, 26);
            txtCategoriesName.TabIndex = 19;
            // 
            // txtCategoriesId
            // 
            txtCategoriesId.BorderThickness = 0;
            txtCategoriesId.CustomizableEdges = customizableEdges11;
            txtCategoriesId.DefaultText = "";
            txtCategoriesId.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoriesId.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoriesId.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesId.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoriesId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesId.Font = new Font("Segoe UI", 9F);
            txtCategoriesId.ForeColor = Color.Blue;
            txtCategoriesId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoriesId.Location = new Point(13, 78);
            txtCategoriesId.Name = "txtCategoriesId";
            txtCategoriesId.PasswordChar = '\0';
            txtCategoriesId.PlaceholderText = "Categories Id";
            txtCategoriesId.SelectedText = "";
            txtCategoriesId.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtCategoriesId.ShadowDecoration.Enabled = true;
            txtCategoriesId.Size = new Size(237, 26);
            txtCategoriesId.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.AntiqueWhite;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(304, 0);
            label2.Name = "label2";
            label2.Size = new Size(118, 32);
            label2.TabIndex = 12;
            label2.Text = "Categories";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.AntiqueWhite;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(254, 9);
            label1.Name = "label1";
            label1.Size = new Size(479, 39);
            label1.TabIndex = 11;
            label1.Text = "Online Market Management System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(2, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(138, 178);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // buttonCategoriesLogout
            // 
            buttonCategoriesLogout.BorderColor = Color.Transparent;
            buttonCategoriesLogout.CustomizableEdges = customizableEdges13;
            buttonCategoriesLogout.DisabledState.BorderColor = Color.DarkGray;
            buttonCategoriesLogout.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonCategoriesLogout.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonCategoriesLogout.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonCategoriesLogout.FillColor = Color.Violet;
            buttonCategoriesLogout.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCategoriesLogout.ForeColor = Color.White;
            buttonCategoriesLogout.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonCategoriesLogout.Location = new Point(12, 443);
            buttonCategoriesLogout.Name = "buttonCategoriesLogout";
            buttonCategoriesLogout.ShadowDecoration.CustomizableEdges = customizableEdges14;
            buttonCategoriesLogout.Size = new Size(108, 26);
            buttonCategoriesLogout.TabIndex = 25;
            buttonCategoriesLogout.Text = "LOGOUT";
            buttonCategoriesLogout.Click += buttonCategoriesLogout_Click;
            // 
            // buttonProductCategories
            // 
            buttonProductCategories.BorderColor = Color.Transparent;
            buttonProductCategories.CustomizableEdges = customizableEdges15;
            buttonProductCategories.DisabledState.BorderColor = Color.DarkGray;
            buttonProductCategories.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductCategories.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductCategories.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductCategories.FillColor = Color.LightBlue;
            buttonProductCategories.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductCategories.ForeColor = Color.White;
            buttonProductCategories.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductCategories.Location = new Point(12, 184);
            buttonProductCategories.Name = "buttonProductCategories";
            buttonProductCategories.ShadowDecoration.CustomizableEdges = customizableEdges16;
            buttonProductCategories.Size = new Size(117, 26);
            buttonProductCategories.TabIndex = 29;
            buttonProductCategories.Text = "Product";
            buttonProductCategories.TextAlign = HorizontalAlignment.Left;
            buttonProductCategories.Click += buttonProductCategories_Click;
            // 
            // buttonSellingDetails
            // 
            buttonSellingDetails.BorderColor = Color.Transparent;
            buttonSellingDetails.CustomizableEdges = customizableEdges17;
            buttonSellingDetails.DisabledState.BorderColor = Color.DarkGray;
            buttonSellingDetails.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonSellingDetails.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonSellingDetails.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonSellingDetails.FillColor = Color.DeepSkyBlue;
            buttonSellingDetails.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonSellingDetails.ForeColor = Color.White;
            buttonSellingDetails.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonSellingDetails.Location = new Point(12, 234);
            buttonSellingDetails.Name = "buttonSellingDetails";
            buttonSellingDetails.ShadowDecoration.CustomizableEdges = customizableEdges18;
            buttonSellingDetails.Size = new Size(117, 26);
            buttonSellingDetails.TabIndex = 30;
            buttonSellingDetails.Text = "Selling Details";
            buttonSellingDetails.TextAlign = HorizontalAlignment.Left;
            buttonSellingDetails.Click += buttonSellingDetails_Click;
            // 
            // AdminView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 481);
            Controls.Add(buttonSellingDetails);
            Controls.Add(buttonProductCategories);
            Controls.Add(buttonCategoriesLogout);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AdminView";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AdminView";
            Load += AdminView_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewCategories).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoriesDescribtion;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoriesName;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoriesId;
        private Guna.UI2.WinForms.Guna2Button buttonCategoriesUpdate;
        private Guna.UI2.WinForms.Guna2Button buttonCategoriesDelete;
        private Guna.UI2.WinForms.Guna2Button buttonCategoriesAdd;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridViewCategories;
        private Guna.UI2.WinForms.Guna2Button buttonCategoriesLogout;
        private Guna.UI2.WinForms.Guna2Button buttonProductCategories;
        private Guna.UI2.WinForms.Guna2Button buttonSellingDetails;
    }
}