﻿namespace OnlineMarketManagmnetSystem
{
    partial class Bkash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bkash));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            picturenone = new PictureBox();
            bkphone = new Guna.UI2.WinForms.Guna2TextBox();
            buttonBkashEnter = new Guna.UI2.WinForms.Guna2Button();
            buttonBkashCancle = new Guna.UI2.WinForms.Guna2Button();
            buttonBkashBack = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MediumSeaGreen;
            label1.Location = new Point(399, 82);
            label1.Name = "label1";
            label1.Size = new Size(455, 37);
            label1.TabIndex = 2;
            label1.Text = "Enter Your Bkash Account Number";
            label1.Click += label1_Click;
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(27, 113);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(313, 265);
            picturenone.SizeMode = PictureBoxSizeMode.StretchImage;
            picturenone.TabIndex = 3;
            picturenone.TabStop = false;
            // 
            // bkphone
            // 
            bkphone.BorderThickness = 0;
            bkphone.CustomizableEdges = customizableEdges1;
            bkphone.DefaultText = "";
            bkphone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            bkphone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            bkphone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            bkphone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            bkphone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            bkphone.Font = new Font("Segoe UI", 9F);
            bkphone.ForeColor = Color.Blue;
            bkphone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            bkphone.Location = new Point(499, 172);
            bkphone.Name = "bkphone";
            bkphone.PasswordChar = '\0';
            bkphone.PlaceholderForeColor = Color.Blue;
            bkphone.PlaceholderText = "      +8801---------";
            bkphone.SelectedText = "";
            bkphone.ShadowDecoration.CustomizableEdges = customizableEdges2;
            bkphone.ShadowDecoration.Enabled = true;
            bkphone.Size = new Size(237, 26);
            bkphone.TabIndex = 19;
            // 
            // buttonBkashEnter
            // 
            buttonBkashEnter.BorderColor = Color.Transparent;
            buttonBkashEnter.CustomizableEdges = customizableEdges3;
            buttonBkashEnter.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashEnter.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashEnter.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashEnter.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashEnter.FillColor = Color.SpringGreen;
            buttonBkashEnter.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashEnter.ForeColor = Color.White;
            buttonBkashEnter.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashEnter.Location = new Point(499, 280);
            buttonBkashEnter.Name = "buttonBkashEnter";
            buttonBkashEnter.ShadowDecoration.CustomizableEdges = customizableEdges4;
            buttonBkashEnter.Size = new Size(80, 26);
            buttonBkashEnter.TabIndex = 22;
            buttonBkashEnter.Text = "Enter";
            buttonBkashEnter.Click += buttonBkashEnter_Click;
            // 
            // buttonBkashCancle
            // 
            buttonBkashCancle.BorderColor = Color.Transparent;
            buttonBkashCancle.CustomizableEdges = customizableEdges5;
            buttonBkashCancle.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashCancle.FillColor = Color.Red;
            buttonBkashCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashCancle.ForeColor = Color.White;
            buttonBkashCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashCancle.Location = new Point(652, 280);
            buttonBkashCancle.Name = "buttonBkashCancle";
            buttonBkashCancle.ShadowDecoration.CustomizableEdges = customizableEdges6;
            buttonBkashCancle.Size = new Size(84, 26);
            buttonBkashCancle.TabIndex = 23;
            buttonBkashCancle.Text = "Cancle";
            buttonBkashCancle.Click += buttonBkashCancle_Click;
            // 
            // buttonBkashBack
            // 
            buttonBkashBack.BorderColor = Color.Transparent;
            buttonBkashBack.CustomizableEdges = customizableEdges7;
            buttonBkashBack.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashBack.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashBack.FillColor = Color.LightSkyBlue;
            buttonBkashBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashBack.ForeColor = Color.White;
            buttonBkashBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashBack.Location = new Point(41, 443);
            buttonBkashBack.Name = "buttonBkashBack";
            buttonBkashBack.ShadowDecoration.CustomizableEdges = customizableEdges8;
            buttonBkashBack.Size = new Size(80, 26);
            buttonBkashBack.TabIndex = 24;
            buttonBkashBack.Text = "Back";
            buttonBkashBack.Click += buttonBkashBack_Click;
            // 
            // Bkash
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Pink;
            ClientSize = new Size(934, 481);
            Controls.Add(buttonBkashBack);
            Controls.Add(buttonBkashCancle);
            Controls.Add(buttonBkashEnter);
            Controls.Add(bkphone);
            Controls.Add(picturenone);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Bkash";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bkash";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private PictureBox picturenone;
        private Guna.UI2.WinForms.Guna2TextBox bkphone;
        private Guna.UI2.WinForms.Guna2Button buttonBkashEnter;
        private Guna.UI2.WinForms.Guna2Button buttonBkashCancle;
        private Guna.UI2.WinForms.Guna2Button buttonBkashBack;
    }
}