﻿namespace OnlineMarketManagmnetSystem
{
    partial class Rocket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rocket));
            rbuttonBkashBack = new Guna.UI2.WinForms.Guna2Button();
            rbuttoBkashCancle = new Guna.UI2.WinForms.Guna2Button();
            rbuttonBkashEnter = new Guna.UI2.WinForms.Guna2Button();
            rphone = new Guna.UI2.WinForms.Guna2TextBox();
            picturenone = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // rbuttonBkashBack
            // 
            rbuttonBkashBack.BorderColor = Color.Transparent;
            rbuttonBkashBack.CustomizableEdges = customizableEdges9;
            rbuttonBkashBack.DisabledState.BorderColor = Color.DarkGray;
            rbuttonBkashBack.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttonBkashBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttonBkashBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttonBkashBack.FillColor = Color.LightSkyBlue;
            rbuttonBkashBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttonBkashBack.ForeColor = Color.White;
            rbuttonBkashBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttonBkashBack.Location = new Point(68, 408);
            rbuttonBkashBack.Name = "rbuttonBkashBack";
            rbuttonBkashBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            rbuttonBkashBack.Size = new Size(80, 26);
            rbuttonBkashBack.TabIndex = 30;
            rbuttonBkashBack.Text = "Back";
            rbuttonBkashBack.Click += rbuttonBkashBack_Click;
            // 
            // rbuttoBkashCancle
            // 
            rbuttoBkashCancle.BorderColor = Color.Transparent;
            rbuttoBkashCancle.CustomizableEdges = customizableEdges11;
            rbuttoBkashCancle.DisabledState.BorderColor = Color.DarkGray;
            rbuttoBkashCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttoBkashCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttoBkashCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttoBkashCancle.FillColor = Color.Red;
            rbuttoBkashCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttoBkashCancle.ForeColor = Color.White;
            rbuttoBkashCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttoBkashCancle.Location = new Point(679, 245);
            rbuttoBkashCancle.Name = "rbuttoBkashCancle";
            rbuttoBkashCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            rbuttoBkashCancle.Size = new Size(84, 26);
            rbuttoBkashCancle.TabIndex = 29;
            rbuttoBkashCancle.Text = "Cancle";
            rbuttoBkashCancle.Click += rbuttoBkashCancle_Click;
            // 
            // rbuttonBkashEnter
            // 
            rbuttonBkashEnter.BorderColor = Color.Transparent;
            rbuttonBkashEnter.CustomizableEdges = customizableEdges13;
            rbuttonBkashEnter.DisabledState.BorderColor = Color.DarkGray;
            rbuttonBkashEnter.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttonBkashEnter.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttonBkashEnter.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttonBkashEnter.FillColor = Color.SpringGreen;
            rbuttonBkashEnter.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttonBkashEnter.ForeColor = Color.White;
            rbuttonBkashEnter.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttonBkashEnter.Location = new Point(526, 245);
            rbuttonBkashEnter.Name = "rbuttonBkashEnter";
            rbuttonBkashEnter.ShadowDecoration.CustomizableEdges = customizableEdges14;
            rbuttonBkashEnter.Size = new Size(80, 26);
            rbuttonBkashEnter.TabIndex = 28;
            rbuttonBkashEnter.Text = "Enter";
            rbuttonBkashEnter.Click += rbuttonBkashEnter_Click;
            // 
            // rphone
            // 
            rphone.BorderThickness = 0;
            rphone.CustomizableEdges = customizableEdges15;
            rphone.DefaultText = "";
            rphone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            rphone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            rphone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            rphone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            rphone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            rphone.Font = new Font("Segoe UI", 9F);
            rphone.ForeColor = Color.Blue;
            rphone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            rphone.Location = new Point(526, 137);
            rphone.Name = "rphone";
            rphone.PasswordChar = '\0';
            rphone.PlaceholderForeColor = Color.Blue;
            rphone.PlaceholderText = "      +8801---------";
            rphone.SelectedText = "";
            rphone.ShadowDecoration.CustomizableEdges = customizableEdges16;
            rphone.ShadowDecoration.Enabled = true;
            rphone.Size = new Size(237, 26);
            rphone.TabIndex = 27;
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(54, 78);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(310, 222);
            picturenone.SizeMode = PictureBoxSizeMode.StretchImage;
            picturenone.TabIndex = 26;
            picturenone.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(426, 47);
            label1.Name = "label1";
            label1.Size = new Size(468, 37);
            label1.TabIndex = 25;
            label1.Text = "Enter Your Rocket Account Number";
            // 
            // Rocket
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Fuchsia;
            ClientSize = new Size(934, 481);
            Controls.Add(rbuttonBkashBack);
            Controls.Add(rbuttoBkashCancle);
            Controls.Add(rbuttonBkashEnter);
            Controls.Add(rphone);
            Controls.Add(picturenone);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Rocket";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Rocket";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button rbuttonBkashBack;
        private Guna.UI2.WinForms.Guna2Button rbuttoBkashCancle;
        private Guna.UI2.WinForms.Guna2Button rbuttonBkashEnter;
        private Guna.UI2.WinForms.Guna2TextBox rphone;
        private PictureBox picturenone;
        private Label label1;
    }
}