﻿namespace OnlineMarketManagmnetSystem
{
    partial class AdminRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminRegistration));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            txtPrePassword = new Guna.UI2.WinForms.Guna2TextBox();
            buttonLinkLogin = new LinkLabel();
            buttonRegistrationClear = new Guna.UI2.WinForms.Guna2Button();
            abuttonRegistration = new Guna.UI2.WinForms.Guna2Button();
            txtNewAdminPassword = new Guna.UI2.WinForms.Guna2TextBox();
            txtNewAdminName = new Guna.UI2.WinForms.Guna2TextBox();
            txtPreAdminName = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(77, 103);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(288, 289);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(886, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 34);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 40;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // txtPrePassword
            // 
            txtPrePassword.BorderThickness = 0;
            txtPrePassword.CustomizableEdges = customizableEdges1;
            txtPrePassword.DefaultText = "";
            txtPrePassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrePassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrePassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrePassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrePassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrePassword.Font = new Font("Segoe UI", 9F);
            txtPrePassword.ForeColor = Color.Blue;
            txtPrePassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrePassword.Location = new Point(556, 179);
            txtPrePassword.Name = "txtPrePassword";
            txtPrePassword.PasswordChar = '*';
            txtPrePassword.PlaceholderForeColor = Color.Blue;
            txtPrePassword.PlaceholderText = "Previous Password";
            txtPrePassword.SelectedText = "";
            txtPrePassword.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtPrePassword.ShadowDecoration.Enabled = true;
            txtPrePassword.Size = new Size(237, 23);
            txtPrePassword.TabIndex = 39;
            // 
            // buttonLinkLogin
            // 
            buttonLinkLogin.AutoSize = true;
            buttonLinkLogin.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonLinkLogin.Location = new Point(627, 443);
            buttonLinkLogin.Name = "buttonLinkLogin";
            buttonLinkLogin.Size = new Size(132, 20);
            buttonLinkLogin.TabIndex = 38;
            buttonLinkLogin.TabStop = true;
            buttonLinkLogin.Text = "Click here to Login";
            buttonLinkLogin.LinkClicked += buttonLinkLogin_LinkClicked;
            // 
            // buttonRegistrationClear
            // 
            buttonRegistrationClear.BorderColor = Color.Transparent;
            buttonRegistrationClear.CustomizableEdges = customizableEdges3;
            buttonRegistrationClear.DisabledState.BorderColor = Color.DarkGray;
            buttonRegistrationClear.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonRegistrationClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonRegistrationClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonRegistrationClear.FillColor = Color.DarkTurquoise;
            buttonRegistrationClear.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRegistrationClear.ForeColor = Color.White;
            buttonRegistrationClear.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonRegistrationClear.Location = new Point(722, 383);
            buttonRegistrationClear.Name = "buttonRegistrationClear";
            buttonRegistrationClear.ShadowDecoration.CustomizableEdges = customizableEdges4;
            buttonRegistrationClear.Size = new Size(84, 30);
            buttonRegistrationClear.TabIndex = 37;
            buttonRegistrationClear.Text = "Clear";
            buttonRegistrationClear.Click += buttonRegistrationClear_Click;
            // 
            // abuttonRegistration
            // 
            abuttonRegistration.BorderColor = Color.Transparent;
            abuttonRegistration.CustomizableEdges = customizableEdges5;
            abuttonRegistration.DisabledState.BorderColor = Color.DarkGray;
            abuttonRegistration.DisabledState.CustomBorderColor = Color.DarkGray;
            abuttonRegistration.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            abuttonRegistration.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            abuttonRegistration.FillColor = Color.Blue;
            abuttonRegistration.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            abuttonRegistration.ForeColor = Color.White;
            abuttonRegistration.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            abuttonRegistration.Location = new Point(574, 383);
            abuttonRegistration.Name = "abuttonRegistration";
            abuttonRegistration.ShadowDecoration.CustomizableEdges = customizableEdges6;
            abuttonRegistration.Size = new Size(84, 30);
            abuttonRegistration.TabIndex = 36;
            abuttonRegistration.Text = "Update";
            abuttonRegistration.Click += abuttonRegistration_Click;
            // 
            // txtNewAdminPassword
            // 
            txtNewAdminPassword.BorderThickness = 0;
            txtNewAdminPassword.CustomizableEdges = customizableEdges7;
            txtNewAdminPassword.DefaultText = "";
            txtNewAdminPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNewAdminPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNewAdminPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNewAdminPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNewAdminPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNewAdminPassword.Font = new Font("Segoe UI", 9F);
            txtNewAdminPassword.ForeColor = Color.Blue;
            txtNewAdminPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNewAdminPassword.Location = new Point(556, 275);
            txtNewAdminPassword.Name = "txtNewAdminPassword";
            txtNewAdminPassword.PasswordChar = '*';
            txtNewAdminPassword.PlaceholderForeColor = Color.Blue;
            txtNewAdminPassword.PlaceholderText = "New Password";
            txtNewAdminPassword.SelectedText = "";
            txtNewAdminPassword.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtNewAdminPassword.ShadowDecoration.Enabled = true;
            txtNewAdminPassword.Size = new Size(237, 23);
            txtNewAdminPassword.TabIndex = 33;
            // 
            // txtNewAdminName
            // 
            txtNewAdminName.BorderThickness = 0;
            txtNewAdminName.CustomizableEdges = customizableEdges9;
            txtNewAdminName.DefaultText = "";
            txtNewAdminName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNewAdminName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNewAdminName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNewAdminName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNewAdminName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNewAdminName.Font = new Font("Segoe UI", 9F);
            txtNewAdminName.ForeColor = Color.Blue;
            txtNewAdminName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNewAdminName.Location = new Point(556, 227);
            txtNewAdminName.Name = "txtNewAdminName";
            txtNewAdminName.PasswordChar = '\0';
            txtNewAdminName.PlaceholderForeColor = Color.Blue;
            txtNewAdminName.PlaceholderText = "New User Name";
            txtNewAdminName.SelectedText = "";
            txtNewAdminName.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtNewAdminName.ShadowDecoration.Enabled = true;
            txtNewAdminName.Size = new Size(237, 23);
            txtNewAdminName.TabIndex = 32;
            // 
            // txtPreAdminName
            // 
            txtPreAdminName.BorderThickness = 0;
            txtPreAdminName.CustomizableEdges = customizableEdges11;
            txtPreAdminName.DefaultText = "";
            txtPreAdminName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPreAdminName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPreAdminName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPreAdminName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPreAdminName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPreAdminName.Font = new Font("Segoe UI", 9F);
            txtPreAdminName.ForeColor = Color.Blue;
            txtPreAdminName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPreAdminName.Location = new Point(556, 131);
            txtPreAdminName.Name = "txtPreAdminName";
            txtPreAdminName.PasswordChar = '\0';
            txtPreAdminName.PlaceholderForeColor = Color.Blue;
            txtPreAdminName.PlaceholderText = "Previous User Name";
            txtPreAdminName.SelectedText = "";
            txtPreAdminName.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtPreAdminName.ShadowDecoration.Enabled = true;
            txtPreAdminName.Size = new Size(237, 23);
            txtPreAdminName.TabIndex = 31;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(351, 9);
            label1.Name = "label1";
            label1.Size = new Size(267, 37);
            label1.TabIndex = 30;
            label1.Text = "Admin Registration";
            // 
            // AdminRegistration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(934, 481);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox2);
            Controls.Add(txtPrePassword);
            Controls.Add(buttonLinkLogin);
            Controls.Add(buttonRegistrationClear);
            Controls.Add(abuttonRegistration);
            Controls.Add(txtNewAdminPassword);
            Controls.Add(txtNewAdminName);
            Controls.Add(txtPreAdminName);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AdminRegistration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AdminRegistration";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2TextBox txtPrePassword;
        private LinkLabel buttonLinkLogin;
        private Guna.UI2.WinForms.Guna2Button buttonRegistrationClear;
        private Guna.UI2.WinForms.Guna2Button abuttonRegistration;
        private Guna.UI2.WinForms.Guna2TextBox txtNewAdminPassword;
        private Guna.UI2.WinForms.Guna2TextBox txtNewAdminName;
        private Guna.UI2.WinForms.Guna2TextBox txtPreAdminName;
        private Label label1;
    }
}