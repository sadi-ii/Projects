﻿namespace OnlineMarketManagmnetSystem
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            label1 = new Label();
            txtCustomerName = new Guna.UI2.WinForms.Guna2TextBox();
            txtCustomerAge = new Guna.UI2.WinForms.Guna2TextBox();
            txtCustomerAddress = new Guna.UI2.WinForms.Guna2TextBox();
            txtCustomerPhone = new Guna.UI2.WinForms.Guna2TextBox();
            comboboxRegistrationGender = new ComboBox();
            buttonRegistration = new Guna.UI2.WinForms.Guna2Button();
            buttonRegistrationClear = new Guna.UI2.WinForms.Guna2Button();
            buttonLinkLogin = new LinkLabel();
            txtRegistrationPassword = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(521, 22);
            label1.Name = "label1";
            label1.Size = new Size(306, 37);
            label1.TabIndex = 0;
            label1.Text = "Customer Registration";
            // 
            // txtCustomerName
            // 
            txtCustomerName.BorderThickness = 0;
            txtCustomerName.CustomizableEdges = customizableEdges1;
            txtCustomerName.DefaultText = "";
            txtCustomerName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCustomerName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCustomerName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerName.Font = new Font("Segoe UI", 9F);
            txtCustomerName.ForeColor = Color.Blue;
            txtCustomerName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerName.Location = new Point(559, 99);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.PasswordChar = '\0';
            txtCustomerName.PlaceholderForeColor = Color.Blue;
            txtCustomerName.PlaceholderText = "User Name";
            txtCustomerName.SelectedText = "";
            txtCustomerName.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtCustomerName.ShadowDecoration.Enabled = true;
            txtCustomerName.Size = new Size(237, 23);
            txtCustomerName.TabIndex = 19;
            // 
            // txtCustomerAge
            // 
            txtCustomerAge.BorderThickness = 0;
            txtCustomerAge.CustomizableEdges = customizableEdges3;
            txtCustomerAge.DefaultText = "";
            txtCustomerAge.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCustomerAge.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCustomerAge.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerAge.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerAge.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerAge.Font = new Font("Segoe UI", 9F);
            txtCustomerAge.ForeColor = Color.Blue;
            txtCustomerAge.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerAge.Location = new Point(559, 185);
            txtCustomerAge.Name = "txtCustomerAge";
            txtCustomerAge.PasswordChar = '\0';
            txtCustomerAge.PlaceholderForeColor = Color.Blue;
            txtCustomerAge.PlaceholderText = "Age";
            txtCustomerAge.SelectedText = "";
            txtCustomerAge.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtCustomerAge.ShadowDecoration.Enabled = true;
            txtCustomerAge.Size = new Size(237, 23);
            txtCustomerAge.TabIndex = 20;
            // 
            // txtCustomerAddress
            // 
            txtCustomerAddress.BorderThickness = 0;
            txtCustomerAddress.CustomizableEdges = customizableEdges5;
            txtCustomerAddress.DefaultText = "";
            txtCustomerAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCustomerAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCustomerAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerAddress.Font = new Font("Segoe UI", 9F);
            txtCustomerAddress.ForeColor = Color.Blue;
            txtCustomerAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerAddress.Location = new Point(559, 271);
            txtCustomerAddress.Name = "txtCustomerAddress";
            txtCustomerAddress.PasswordChar = '\0';
            txtCustomerAddress.PlaceholderForeColor = Color.Blue;
            txtCustomerAddress.PlaceholderText = "Full Address";
            txtCustomerAddress.SelectedText = "";
            txtCustomerAddress.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtCustomerAddress.ShadowDecoration.Enabled = true;
            txtCustomerAddress.Size = new Size(237, 23);
            txtCustomerAddress.TabIndex = 21;
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.BorderThickness = 0;
            txtCustomerPhone.CustomizableEdges = customizableEdges7;
            txtCustomerPhone.DefaultText = "";
            txtCustomerPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCustomerPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCustomerPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCustomerPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerPhone.Font = new Font("Segoe UI", 9F);
            txtCustomerPhone.ForeColor = Color.Blue;
            txtCustomerPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCustomerPhone.Location = new Point(559, 314);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.PasswordChar = '\0';
            txtCustomerPhone.PlaceholderForeColor = Color.Blue;
            txtCustomerPhone.PlaceholderText = "Mobile Number";
            txtCustomerPhone.SelectedText = "";
            txtCustomerPhone.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtCustomerPhone.ShadowDecoration.Enabled = true;
            txtCustomerPhone.Size = new Size(237, 23);
            txtCustomerPhone.TabIndex = 22;
            // 
            // comboboxRegistrationGender
            // 
            comboboxRegistrationGender.BackColor = SystemColors.ButtonHighlight;
            comboboxRegistrationGender.ForeColor = Color.Blue;
            comboboxRegistrationGender.FormattingEnabled = true;
            comboboxRegistrationGender.Items.AddRange(new object[] { "Male", "Female" });
            comboboxRegistrationGender.Location = new Point(559, 228);
            comboboxRegistrationGender.Name = "comboboxRegistrationGender";
            comboboxRegistrationGender.Size = new Size(237, 23);
            comboboxRegistrationGender.TabIndex = 23;
            comboboxRegistrationGender.Text = "Select Gender";
            comboboxRegistrationGender.SelectedIndexChanged += comboboxLogin_SelectedIndexChanged;
            // 
            // buttonRegistration
            // 
            buttonRegistration.BorderColor = Color.Transparent;
            buttonRegistration.CustomizableEdges = customizableEdges9;
            buttonRegistration.DisabledState.BorderColor = Color.DarkGray;
            buttonRegistration.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonRegistration.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonRegistration.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonRegistration.FillColor = Color.Blue;
            buttonRegistration.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRegistration.ForeColor = Color.White;
            buttonRegistration.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonRegistration.Location = new Point(577, 379);
            buttonRegistration.Name = "buttonRegistration";
            buttonRegistration.ShadowDecoration.CustomizableEdges = customizableEdges10;
            buttonRegistration.Size = new Size(84, 30);
            buttonRegistration.TabIndex = 24;
            buttonRegistration.Text = "Register";
            buttonRegistration.Click += buttonRegistration_Click;
            // 
            // buttonRegistrationClear
            // 
            buttonRegistrationClear.BorderColor = Color.Transparent;
            buttonRegistrationClear.CustomizableEdges = customizableEdges11;
            buttonRegistrationClear.DisabledState.BorderColor = Color.DarkGray;
            buttonRegistrationClear.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonRegistrationClear.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonRegistrationClear.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonRegistrationClear.FillColor = Color.DarkTurquoise;
            buttonRegistrationClear.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRegistrationClear.ForeColor = Color.White;
            buttonRegistrationClear.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonRegistrationClear.Location = new Point(725, 379);
            buttonRegistrationClear.Name = "buttonRegistrationClear";
            buttonRegistrationClear.ShadowDecoration.CustomizableEdges = customizableEdges12;
            buttonRegistrationClear.Size = new Size(84, 30);
            buttonRegistrationClear.TabIndex = 25;
            buttonRegistrationClear.Text = "Clear";
            buttonRegistrationClear.Click += buttonRegistrationClear_Click;
            // 
            // buttonLinkLogin
            // 
            buttonLinkLogin.AutoSize = true;
            buttonLinkLogin.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonLinkLogin.Location = new Point(630, 439);
            buttonLinkLogin.Name = "buttonLinkLogin";
            buttonLinkLogin.Size = new Size(132, 20);
            buttonLinkLogin.TabIndex = 26;
            buttonLinkLogin.TabStop = true;
            buttonLinkLogin.Text = "Click here to Login";
            buttonLinkLogin.LinkClicked += buttonLinkLogin_LinkClicked;
            // 
            // txtRegistrationPassword
            // 
            txtRegistrationPassword.BorderThickness = 0;
            txtRegistrationPassword.CustomizableEdges = customizableEdges13;
            txtRegistrationPassword.DefaultText = "";
            txtRegistrationPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRegistrationPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRegistrationPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRegistrationPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRegistrationPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRegistrationPassword.Font = new Font("Segoe UI", 9F);
            txtRegistrationPassword.ForeColor = Color.Blue;
            txtRegistrationPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRegistrationPassword.Location = new Point(559, 142);
            txtRegistrationPassword.Name = "txtRegistrationPassword";
            txtRegistrationPassword.PasswordChar = '*';
            txtRegistrationPassword.PlaceholderForeColor = Color.Blue;
            txtRegistrationPassword.PlaceholderText = "Password";
            txtRegistrationPassword.SelectedText = "";
            txtRegistrationPassword.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtRegistrationPassword.ShadowDecoration.Enabled = true;
            txtRegistrationPassword.Size = new Size(237, 23);
            txtRegistrationPassword.TabIndex = 27;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(889, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 34);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 28;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(80, 99);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(225, 225);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 29;
            pictureBox1.TabStop = false;
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SpringGreen;
            ClientSize = new Size(934, 481);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox2);
            Controls.Add(txtRegistrationPassword);
            Controls.Add(buttonLinkLogin);
            Controls.Add(buttonRegistrationClear);
            Controls.Add(buttonRegistration);
            Controls.Add(comboboxRegistrationGender);
            Controls.Add(txtCustomerPhone);
            Controls.Add(txtCustomerAddress);
            Controls.Add(txtCustomerAge);
            Controls.Add(txtCustomerName);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Registration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registration";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtCustomerName;
        private Guna.UI2.WinForms.Guna2TextBox txtCustomerAge;
        private Guna.UI2.WinForms.Guna2TextBox txtCustomerAddress;
        private Guna.UI2.WinForms.Guna2TextBox txtCustomerPhone;
        private ComboBox comboboxRegistrationGender;
        private Guna.UI2.WinForms.Guna2Button buttonRegistration;
        private Guna.UI2.WinForms.Guna2Button buttonRegistrationClear;
        private LinkLabel buttonLinkLogin;
        private Guna.UI2.WinForms.Guna2TextBox txtRegistrationPassword;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
    }
}