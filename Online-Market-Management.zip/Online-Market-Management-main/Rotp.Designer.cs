﻿namespace OnlineMarketManagmnetSystem
{
    partial class Rotp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rotp));
            rbuttonBkashOtpBack = new Guna.UI2.WinForms.Guna2Button();
            rbuttonBkashotpCancle = new Guna.UI2.WinForms.Guna2Button();
            rbuttonBkashotpConfirm = new Guna.UI2.WinForms.Guna2Button();
            r = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            picturenone = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // rbuttonBkashOtpBack
            // 
            rbuttonBkashOtpBack.BorderColor = Color.Transparent;
            rbuttonBkashOtpBack.CustomizableEdges = customizableEdges9;
            rbuttonBkashOtpBack.DisabledState.BorderColor = Color.DarkGray;
            rbuttonBkashOtpBack.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttonBkashOtpBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttonBkashOtpBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttonBkashOtpBack.FillColor = Color.LightSkyBlue;
            rbuttonBkashOtpBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttonBkashOtpBack.ForeColor = Color.White;
            rbuttonBkashOtpBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttonBkashOtpBack.Location = new Point(73, 399);
            rbuttonBkashOtpBack.Name = "rbuttonBkashOtpBack";
            rbuttonBkashOtpBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            rbuttonBkashOtpBack.Size = new Size(80, 26);
            rbuttonBkashOtpBack.TabIndex = 36;
            rbuttonBkashOtpBack.Text = "Back";
            rbuttonBkashOtpBack.Click += rbuttonBkashOtpBack_Click;
            // 
            // rbuttonBkashotpCancle
            // 
            rbuttonBkashotpCancle.BorderColor = Color.Transparent;
            rbuttonBkashotpCancle.CustomizableEdges = customizableEdges11;
            rbuttonBkashotpCancle.DisabledState.BorderColor = Color.DarkGray;
            rbuttonBkashotpCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttonBkashotpCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttonBkashotpCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttonBkashotpCancle.FillColor = Color.Red;
            rbuttonBkashotpCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttonBkashotpCancle.ForeColor = Color.White;
            rbuttonBkashotpCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttonBkashotpCancle.Location = new Point(684, 236);
            rbuttonBkashotpCancle.Name = "rbuttonBkashotpCancle";
            rbuttonBkashotpCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            rbuttonBkashotpCancle.Size = new Size(84, 26);
            rbuttonBkashotpCancle.TabIndex = 35;
            rbuttonBkashotpCancle.Text = "Cancle";
            rbuttonBkashotpCancle.Click += rbuttonBkashotpCancle_Click;
            // 
            // rbuttonBkashotpConfirm
            // 
            rbuttonBkashotpConfirm.BorderColor = Color.Transparent;
            rbuttonBkashotpConfirm.CustomizableEdges = customizableEdges13;
            rbuttonBkashotpConfirm.DisabledState.BorderColor = Color.DarkGray;
            rbuttonBkashotpConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            rbuttonBkashotpConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            rbuttonBkashotpConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            rbuttonBkashotpConfirm.FillColor = Color.FromArgb(128, 128, 255);
            rbuttonBkashotpConfirm.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbuttonBkashotpConfirm.ForeColor = Color.White;
            rbuttonBkashotpConfirm.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            rbuttonBkashotpConfirm.Location = new Point(531, 236);
            rbuttonBkashotpConfirm.Name = "rbuttonBkashotpConfirm";
            rbuttonBkashotpConfirm.ShadowDecoration.CustomizableEdges = customizableEdges14;
            rbuttonBkashotpConfirm.Size = new Size(101, 26);
            rbuttonBkashotpConfirm.TabIndex = 34;
            rbuttonBkashotpConfirm.Text = "Comfirm";
            rbuttonBkashotpConfirm.Click += rbuttonBkashotpConfirm_Click;
            // 
            // r
            // 
            r.BorderThickness = 0;
            r.CustomizableEdges = customizableEdges15;
            r.DefaultText = "";
            r.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            r.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            r.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            r.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            r.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            r.Font = new Font("Segoe UI", 9F);
            r.ForeColor = Color.Blue;
            r.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            r.Location = new Point(531, 128);
            r.Name = "r";
            r.PasswordChar = '\0';
            r.PlaceholderForeColor = Color.Blue;
            r.PlaceholderText = "      ---------";
            r.SelectedText = "";
            r.ShadowDecoration.CustomizableEdges = customizableEdges16;
            r.ShadowDecoration.Enabled = true;
            r.Size = new Size(237, 26);
            r.TabIndex = 33;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MediumSeaGreen;
            label1.Location = new Point(531, 48);
            label1.Name = "label1";
            label1.Size = new Size(143, 37);
            label1.TabIndex = 31;
            label1.Text = "Enter OTP";
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(55, 100);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(310, 222);
            picturenone.SizeMode = PictureBoxSizeMode.StretchImage;
            picturenone.TabIndex = 37;
            picturenone.TabStop = false;
            // 
            // Rotp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Fuchsia;
            ClientSize = new Size(934, 481);
            Controls.Add(picturenone);
            Controls.Add(rbuttonBkashOtpBack);
            Controls.Add(rbuttonBkashotpCancle);
            Controls.Add(rbuttonBkashotpConfirm);
            Controls.Add(r);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Rotp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Rotp";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button rbuttonBkashOtpBack;
        private Guna.UI2.WinForms.Guna2Button rbuttonBkashotpCancle;
        private Guna.UI2.WinForms.Guna2Button rbuttonBkashotpConfirm;
        private Guna.UI2.WinForms.Guna2TextBox r;
        private Label label1;
        private PictureBox picturenone;
    }
}