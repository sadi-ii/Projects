##### In this Online Market management system project, There are two types of user who can perform his role within some bounded criteria and handle the process properly. The two users are Admin and Customers. The Admin has more accessibility than an employee. The main task of the Admin is to maintain the products of his shop. Here is the description of Admin accessibility in the application 
##### Admin
##### 1. Login : The Admin has to login by his specific username and password. If the password is not matched with the Database record, an error message will be popping up. Or if the password is matched, then he will be able to access the AdminView interface with an popping up welcome message.
##### 2. Reset Admin Details: The current username is “a” and the password is “a”. The Admin can reset his username and password by confirming his previous username and password.
##### 3. See profile : The Admin can see his profile from this AdminView interface.
##### 4.	Add Product: The Admin can show products and make operations like Add, Update, Delete by Product interface.
##### 5. Add Categories: The Admin can show product categories and make operations like Add, Update, Delete by Categories interface.
##### 6.	View Selling Details : The Admin can show product selling details by SellingDetails interface and can reset it.
##### Customers
##### 7.	Registration : Firstly, a customer has to make registration by Customer name, password, age, gender, address and mobile number through Registration interface.
##### 8.	Login : A Customer has to use his login information according to the registration to login into the system. If the ID or password doesn’t match with the Database record then a message will show that invalid password . Or if it matched with the registered information, then he will get the access to the BuyingProduct interface.
##### 9.	Cart: After getting access to BuyingProduct interface he can add products to the Cart by entering the quantity he want. He can also remove products from the cart if he want to change the quantity or don’t want to buy that product.
##### 10.	Buy Product: After adding products to the cart, a customer can show the total price of the products by clicking the refresh button. Then he can click the Buy button.
##### 11.	Payment: After clicking the Buy button a new interface of select payment method will open. Then the customer has to select the payment method. After this another interface will be shown to receive payment details from the customer. And by entering all the necessary information a customer can successfully order products from this shop. 
