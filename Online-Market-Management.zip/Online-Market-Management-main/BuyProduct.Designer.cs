﻿namespace OnlineMarketManagmnetSystem
{
    partial class BuyProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        /*
        #region Windows Form Designer generated code
        
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            buttonProductRefresh = new Guna.UI2.WinForms.Guna2Button();
            this.comboboxBuyingCategories = new ComboBox();
            this.txtBuyingPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtBuyingQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            panel1 = new Panel();
            DataGridViewProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            buttonProductDelete = new Guna.UI2.WinForms.Guna2Button();
            buttonProductAdd = new Guna.UI2.WinForms.Guna2Button();
            this.txtBuyingName = new Guna.UI2.WinForms.Guna2TextBox();
            txtBuyingId = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            buttonProductLogout = new Guna.UI2.WinForms.Guna2Button();
            guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewProduct).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).BeginInit();
            SuspendLayout();
            // 
            // buttonProductRefresh
            // 
            buttonProductRefresh.BorderColor = Color.Transparent;
            buttonProductRefresh.CustomizableEdges = customizableEdges21;
            buttonProductRefresh.DisabledState.BorderColor = Color.DarkGray;
            buttonProductRefresh.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductRefresh.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductRefresh.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductRefresh.FillColor = Color.MediumSpringGreen;
            buttonProductRefresh.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductRefresh.ForeColor = Color.White;
            buttonProductRefresh.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductRefresh.Location = new Point(691, 17);
            buttonProductRefresh.Name = "buttonProductRefresh";
            buttonProductRefresh.ShadowDecoration.CustomizableEdges = customizableEdges22;
            buttonProductRefresh.Size = new Size(93, 23);
            buttonProductRefresh.TabIndex = 29;
            buttonProductRefresh.Text = "REFRESH";
            // 
            // comboboxBuyingCategories
            // 
            this.comboboxBuyingCategories.BackColor = SystemColors.ButtonHighlight;
            this.comboboxBuyingCategories.ForeColor = Color.Blue;
            this.comboboxBuyingCategories.FormattingEnabled = true;
            this.comboboxBuyingCategories.Location = new Point(13, 258);
            this.comboboxBuyingCategories.Name = "comboboxBuyingCategories";
            this.comboboxBuyingCategories.Size = new Size(205, 23);
            this.comboboxBuyingCategories.TabIndex = 27;
            this.comboboxBuyingCategories.Text = "Select Category";
            // 
            // txtBuyingPrice
            // 
            this.txtBuyingPrice.BorderThickness = 0;
            this.txtBuyingPrice.CustomizableEdges = customizableEdges23;
            this.txtBuyingPrice.DefaultText = "";
            this.txtBuyingPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            this.txtBuyingPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            this.txtBuyingPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingPrice.Font = new Font("Segoe UI", 9F);
            this.txtBuyingPrice.ForeColor = Color.Blue;
            this.txtBuyingPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingPrice.Location = new Point(13, 213);
            this.txtBuyingPrice.Name = "txtBuyingPrice";
            this.txtBuyingPrice.PasswordChar = '\0';
            this.txtBuyingPrice.PlaceholderForeColor = Color.Blue;
            this.txtBuyingPrice.PlaceholderText = "Product Price";
            this.txtBuyingPrice.SelectedText = "";
            this.txtBuyingPrice.ShadowDecoration.CustomizableEdges = customizableEdges24;
            this.txtBuyingPrice.Size = new Size(205, 26);
            this.txtBuyingPrice.TabIndex = 26;
            // 
            // txtBuyingQuantity
            // 
            this.txtBuyingQuantity.BorderThickness = 0;
            this.txtBuyingQuantity.CustomizableEdges = customizableEdges25;
            this.txtBuyingQuantity.DefaultText = "";
            this.txtBuyingQuantity.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            this.txtBuyingQuantity.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            this.txtBuyingQuantity.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingQuantity.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingQuantity.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingQuantity.Font = new Font("Segoe UI", 9F);
            this.txtBuyingQuantity.ForeColor = Color.Blue;
            this.txtBuyingQuantity.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingQuantity.Location = new Point(13, 168);
            this.txtBuyingQuantity.Name = "txtBuyingQuantity";
            this.txtBuyingQuantity.PasswordChar = '\0';
            this.txtBuyingQuantity.PlaceholderForeColor = Color.Blue;
            this.txtBuyingQuantity.PlaceholderText = "Product Quantity";
            this.txtBuyingQuantity.SelectedText = "";
            this.txtBuyingQuantity.ShadowDecoration.CustomizableEdges = customizableEdges26;
            this.txtBuyingQuantity.Size = new Size(205, 26);
            this.txtBuyingQuantity.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.AntiqueWhite;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(328, 0);
            label2.Name = "label2";
            label2.Size = new Size(84, 32);
            label2.TabIndex = 12;
            label2.Text = "Buying";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(guna2Button2);
            panel1.Controls.Add(guna2Button1);
            panel1.Controls.Add(guna2DataGridView1);
            panel1.Controls.Add(buttonProductRefresh);
            panel1.Controls.Add(this.comboboxBuyingCategories);
            panel1.Controls.Add(this.txtBuyingPrice);
            panel1.Controls.Add(this.txtBuyingQuantity);
            panel1.Controls.Add(DataGridViewProduct);
            panel1.Controls.Add(buttonProductDelete);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(buttonProductAdd);
            panel1.Controls.Add(this.txtBuyingName);
            panel1.Controls.Add(txtBuyingId);
            panel1.Location = new Point(118, 45);
            panel1.Name = "panel1";
            panel1.Size = new Size(815, 441);
            panel1.TabIndex = 34;
            // 
            // DataGridViewProduct
            // 
            dataGridViewCellStyle7.BackColor = Color.White;
            DataGridViewProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = Color.White;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            DataGridViewProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            DataGridViewProduct.ColumnHeadersHeight = 30;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.White;
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle9.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle9.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.False;
            DataGridViewProduct.DefaultCellStyle = dataGridViewCellStyle9;
            DataGridViewProduct.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.Location = new Point(258, 62);
            DataGridViewProduct.Name = "DataGridViewProduct";
            DataGridViewProduct.RowHeadersVisible = false;
            DataGridViewProduct.Size = new Size(526, 132);
            DataGridViewProduct.TabIndex = 24;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            DataGridViewProduct.ThemeStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            DataGridViewProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            DataGridViewProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            DataGridViewProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            DataGridViewProduct.ThemeStyle.HeaderStyle.Height = 30;
            DataGridViewProduct.ThemeStyle.ReadOnly = false;
            DataGridViewProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            DataGridViewProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            DataGridViewProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            DataGridViewProduct.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            DataGridViewProduct.ThemeStyle.RowsStyle.Height = 25;
            DataGridViewProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            DataGridViewProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // buttonProductDelete
            // 
            buttonProductDelete.BorderColor = Color.Transparent;
            buttonProductDelete.CustomizableEdges = customizableEdges27;
            buttonProductDelete.DisabledState.BorderColor = Color.DarkGray;
            buttonProductDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductDelete.FillColor = Color.Red;
            buttonProductDelete.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductDelete.ForeColor = Color.White;
            buttonProductDelete.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductDelete.Location = new Point(56, 367);
            buttonProductDelete.Name = "buttonProductDelete";
            buttonProductDelete.ShadowDecoration.CustomizableEdges = customizableEdges28;
            buttonProductDelete.Size = new Size(88, 26);
            buttonProductDelete.TabIndex = 22;
            buttonProductDelete.Text = "DELETE";
            // 
            // buttonProductAdd
            // 
            buttonProductAdd.BorderColor = Color.Transparent;
            buttonProductAdd.CustomizableEdges = customizableEdges29;
            buttonProductAdd.DisabledState.BorderColor = Color.DarkGray;
            buttonProductAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductAdd.FillColor = Color.DeepSkyBlue;
            buttonProductAdd.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductAdd.ForeColor = Color.White;
            buttonProductAdd.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductAdd.Location = new Point(13, 300);
            buttonProductAdd.Name = "buttonProductAdd";
            buttonProductAdd.ShadowDecoration.CustomizableEdges = customizableEdges30;
            buttonProductAdd.Size = new Size(205, 26);
            buttonProductAdd.TabIndex = 21;
            buttonProductAdd.Text = "Add To Cart";
            buttonProductAdd.TextAlign = HorizontalAlignment.Left;
            // 
            // txtBuyingName
            // 
            this.txtBuyingName.BorderThickness = 0;
            this.txtBuyingName.CustomizableEdges = customizableEdges31;
            this.txtBuyingName.DefaultText = "";
            this.txtBuyingName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            this.txtBuyingName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            this.txtBuyingName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            this.txtBuyingName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingName.Font = new Font("Segoe UI", 9F);
            this.txtBuyingName.ForeColor = Color.Blue;
            this.txtBuyingName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            this.txtBuyingName.Location = new Point(13, 123);
            this.txtBuyingName.Name = "txtBuyingName";
            this.txtBuyingName.PasswordChar = '\0';
            this.txtBuyingName.PlaceholderForeColor = Color.Blue;
            this.txtBuyingName.PlaceholderText = "Product Name";
            this.txtBuyingName.SelectedText = "";
            this.txtBuyingName.ShadowDecoration.CustomizableEdges = customizableEdges32;
            this.txtBuyingName.Size = new Size(205, 26);
            this.txtBuyingName.TabIndex = 19;
            // 
            // txtBuyingId
            // 
            txtBuyingId.BorderThickness = 0;
            txtBuyingId.CustomizableEdges = customizableEdges33;
            txtBuyingId.DefaultText = "";
            txtBuyingId.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtBuyingId.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtBuyingId.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtBuyingId.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtBuyingId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtBuyingId.Font = new Font("Segoe UI", 9F);
            txtBuyingId.ForeColor = Color.Blue;
            txtBuyingId.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtBuyingId.Location = new Point(13, 78);
            txtBuyingId.Name = "txtBuyingId";
            txtBuyingId.PasswordChar = '\0';
            txtBuyingId.PlaceholderForeColor = Color.Blue;
            txtBuyingId.PlaceholderText = "Product Id";
            txtBuyingId.SelectedText = "";
            txtBuyingId.ShadowDecoration.CustomizableEdges = customizableEdges34;
            txtBuyingId.ShadowDecoration.Enabled = true;
            txtBuyingId.Size = new Size(205, 26);
            txtBuyingId.TabIndex = 18;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(889, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(44, 34);
            pictureBox2.TabIndex = 33;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(12, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 50);
            pictureBox1.TabIndex = 38;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.AntiqueWhite;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(257, 3);
            label1.Name = "label1";
            label1.Size = new Size(479, 39);
            label1.TabIndex = 35;
            label1.Text = "Online Market Management System";
            // 
            // buttonProductLogout
            // 
            buttonProductLogout.BorderColor = Color.Transparent;
            buttonProductLogout.CustomizableEdges = customizableEdges35;
            buttonProductLogout.DisabledState.BorderColor = Color.DarkGray;
            buttonProductLogout.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonProductLogout.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonProductLogout.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonProductLogout.FillColor = Color.Violet;
            buttonProductLogout.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProductLogout.ForeColor = Color.White;
            buttonProductLogout.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonProductLogout.Location = new Point(12, 446);
            buttonProductLogout.Name = "buttonProductLogout";
            buttonProductLogout.ShadowDecoration.CustomizableEdges = customizableEdges36;
            buttonProductLogout.Size = new Size(100, 26);
            buttonProductLogout.TabIndex = 39;
            buttonProductLogout.Text = "LOGOUT";
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle10.BackColor = Color.White;
            guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle11.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle11.ForeColor = Color.White;
            dataGridViewCellStyle11.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.True;
            guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            guna2DataGridView1.ColumnHeadersHeight = 30;
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.White;
            dataGridViewCellStyle12.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle12.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle12.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.False;
            guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle12;
            guna2DataGridView1.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.Location = new Point(258, 213);
            guna2DataGridView1.Name = "guna2DataGridView1";
            guna2DataGridView1.RowHeadersVisible = false;
            guna2DataGridView1.Size = new Size(526, 180);
            guna2DataGridView1.TabIndex = 30;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 30;
            guna2DataGridView1.ThemeStyle.ReadOnly = false;
            guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            guna2DataGridView1.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView1.ThemeStyle.RowsStyle.Height = 25;
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // guna2Button1
            // 
            guna2Button1.BorderColor = Color.Transparent;
            guna2Button1.CustomizableEdges = customizableEdges37;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.RoyalBlue;
            guna2Button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            guna2Button1.Location = new Point(366, 398);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges38;
            guna2Button1.Size = new Size(80, 26);
            guna2Button1.TabIndex = 31;
            guna2Button1.Text = "ADD";
            // 
            // guna2Button2
            // 
            guna2Button2.BorderColor = Color.Transparent;
            guna2Button2.CustomizableEdges = customizableEdges39;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.RoyalBlue;
            guna2Button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            guna2Button2.Location = new Point(538, 398);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges40;
            guna2Button2.Size = new Size(80, 26);
            guna2Button2.TabIndex = 32;
            guna2Button2.Text = "ADD";
            // 
            // BuyProduct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 481);
            Controls.Add(panel1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(buttonProductLogout);
            FormBorderStyle = FormBorderStyle.None;
            Name = "BuyProduct";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BuyProduct";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridViewProduct).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
*/
        private Guna.UI2.WinForms.Guna2Button buttonBuyingRefresh;
        private ComboBox comboBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtBuyingPrice;
        private Guna.UI2.WinForms.Guna2TextBox txtBuyingQuantity;
        private Label label2;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridViewBuyingDetails;
        private Guna.UI2.WinForms.Guna2Button buttonBuyingRemove;
        private Guna.UI2.WinForms.Guna2Button buttonProductDelete;
        private Guna.UI2.WinForms.Guna2Button buttonBuyingAddToCart;
        private Guna.UI2.WinForms.Guna2TextBox txtBuyingName;
        private Guna.UI2.WinForms.Guna2TextBox txtBuyingId;
        private PictureBox pictureBox2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button buttonBuyingLogout;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2DataGridView DataGridViewBuyingCart;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Button buttonBuyingBuy;
        private Label labelTotalAmount;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button buttonProductSearchb;
        private ComboBox comboboxSearchCategoryb;
        //private Guna.UI2.WinForms.Guna2TextBox txtBuyingId;
    }
}