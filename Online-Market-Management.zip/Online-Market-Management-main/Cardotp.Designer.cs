﻿namespace OnlineMarketManagmnetSystem
{
    partial class Cardotp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cardotp));
            cbuttonBkashOtpBack = new Guna.UI2.WinForms.Guna2Button();
            cbuttonBkashotpCancle = new Guna.UI2.WinForms.Guna2Button();
            cbuttonBkashotpConfirm = new Guna.UI2.WinForms.Guna2Button();
            c = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            picturenone = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)picturenone).BeginInit();
            SuspendLayout();
            // 
            // cbuttonBkashOtpBack
            // 
            cbuttonBkashOtpBack.BorderColor = Color.Transparent;
            cbuttonBkashOtpBack.CustomizableEdges = customizableEdges9;
            cbuttonBkashOtpBack.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashOtpBack.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashOtpBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashOtpBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashOtpBack.FillColor = Color.LightSkyBlue;
            cbuttonBkashOtpBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashOtpBack.ForeColor = Color.White;
            cbuttonBkashOtpBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashOtpBack.Location = new Point(64, 409);
            cbuttonBkashOtpBack.Name = "cbuttonBkashOtpBack";
            cbuttonBkashOtpBack.ShadowDecoration.CustomizableEdges = customizableEdges10;
            cbuttonBkashOtpBack.Size = new Size(80, 26);
            cbuttonBkashOtpBack.TabIndex = 36;
            cbuttonBkashOtpBack.Text = "Back";
            cbuttonBkashOtpBack.Click += cbuttonBkashOtpBack_Click;
            // 
            // cbuttonBkashotpCancle
            // 
            cbuttonBkashotpCancle.BorderColor = Color.Transparent;
            cbuttonBkashotpCancle.CustomizableEdges = customizableEdges11;
            cbuttonBkashotpCancle.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashotpCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashotpCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashotpCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashotpCancle.FillColor = Color.Red;
            cbuttonBkashotpCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashotpCancle.ForeColor = Color.White;
            cbuttonBkashotpCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashotpCancle.Location = new Point(738, 240);
            cbuttonBkashotpCancle.Name = "cbuttonBkashotpCancle";
            cbuttonBkashotpCancle.ShadowDecoration.CustomizableEdges = customizableEdges12;
            cbuttonBkashotpCancle.Size = new Size(84, 26);
            cbuttonBkashotpCancle.TabIndex = 35;
            cbuttonBkashotpCancle.Text = "Cancle";
            cbuttonBkashotpCancle.Click += cbuttonBkashotpCancle_Click;
            // 
            // cbuttonBkashotpConfirm
            // 
            cbuttonBkashotpConfirm.BorderColor = Color.Transparent;
            cbuttonBkashotpConfirm.CustomizableEdges = customizableEdges13;
            cbuttonBkashotpConfirm.DisabledState.BorderColor = Color.DarkGray;
            cbuttonBkashotpConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            cbuttonBkashotpConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cbuttonBkashotpConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cbuttonBkashotpConfirm.FillColor = Color.FromArgb(128, 128, 255);
            cbuttonBkashotpConfirm.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cbuttonBkashotpConfirm.ForeColor = Color.White;
            cbuttonBkashotpConfirm.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            cbuttonBkashotpConfirm.Location = new Point(585, 240);
            cbuttonBkashotpConfirm.Name = "cbuttonBkashotpConfirm";
            cbuttonBkashotpConfirm.ShadowDecoration.CustomizableEdges = customizableEdges14;
            cbuttonBkashotpConfirm.Size = new Size(101, 26);
            cbuttonBkashotpConfirm.TabIndex = 34;
            cbuttonBkashotpConfirm.Text = "Comfirm";
            cbuttonBkashotpConfirm.Click += cbuttonBkashotpConfirm_Click;
            // 
            // c
            // 
            c.BorderThickness = 0;
            c.CustomizableEdges = customizableEdges15;
            c.DefaultText = "";
            c.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            c.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            c.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            c.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            c.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            c.Font = new Font("Segoe UI", 9F);
            c.ForeColor = Color.Blue;
            c.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            c.Location = new Point(585, 132);
            c.Name = "c";
            c.PasswordChar = '\0';
            c.PlaceholderForeColor = Color.Blue;
            c.PlaceholderText = "      ---------";
            c.SelectedText = "";
            c.ShadowDecoration.CustomizableEdges = customizableEdges16;
            c.ShadowDecoration.Enabled = true;
            c.Size = new Size(237, 26);
            c.TabIndex = 33;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(585, 52);
            label1.Name = "label1";
            label1.Size = new Size(143, 37);
            label1.TabIndex = 31;
            label1.Text = "Enter OTP";
            // 
            // picturenone
            // 
            picturenone.Image = (Image)resources.GetObject("picturenone.Image");
            picturenone.Location = new Point(64, 88);
            picturenone.Name = "picturenone";
            picturenone.Size = new Size(368, 265);
            picturenone.SizeMode = PictureBoxSizeMode.Zoom;
            picturenone.TabIndex = 37;
            picturenone.TabStop = false;
            // 
            // Cardotp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(934, 481);
            Controls.Add(picturenone);
            Controls.Add(cbuttonBkashOtpBack);
            Controls.Add(cbuttonBkashotpCancle);
            Controls.Add(cbuttonBkashotpConfirm);
            Controls.Add(c);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Cardotp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cardotp";
            ((System.ComponentModel.ISupportInitialize)picturenone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button cbuttonBkashOtpBack;
        private Guna.UI2.WinForms.Guna2Button cbuttonBkashotpCancle;
        private Guna.UI2.WinForms.Guna2Button cbuttonBkashotpConfirm;
        private Guna.UI2.WinForms.Guna2TextBox c;
        private Label label1;
        private PictureBox picturenone;
    }
}