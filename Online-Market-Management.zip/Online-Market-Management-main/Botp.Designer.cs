﻿namespace OnlineMarketManagmnetSystem
{
    partial class Botp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Botp));
            buttonBkashOtpBack = new Guna.UI2.WinForms.Guna2Button();
            buttonBkashotpCancle = new Guna.UI2.WinForms.Guna2Button();
            buttonBkashotpConfirm = new Guna.UI2.WinForms.Guna2Button();
            bk = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // buttonBkashOtpBack
            // 
            buttonBkashOtpBack.BorderColor = Color.Transparent;
            buttonBkashOtpBack.CustomizableEdges = customizableEdges1;
            buttonBkashOtpBack.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashOtpBack.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashOtpBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashOtpBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashOtpBack.FillColor = Color.LightSkyBlue;
            buttonBkashOtpBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashOtpBack.ForeColor = Color.White;
            buttonBkashOtpBack.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashOtpBack.Location = new Point(64, 411);
            buttonBkashOtpBack.Name = "buttonBkashOtpBack";
            buttonBkashOtpBack.ShadowDecoration.CustomizableEdges = customizableEdges2;
            buttonBkashOtpBack.Size = new Size(80, 26);
            buttonBkashOtpBack.TabIndex = 30;
            buttonBkashOtpBack.Text = "Back";
            buttonBkashOtpBack.Click += buttonBkashOtpBack_Click;
            // 
            // buttonBkashotpCancle
            // 
            buttonBkashotpCancle.BorderColor = Color.Transparent;
            buttonBkashotpCancle.CustomizableEdges = customizableEdges3;
            buttonBkashotpCancle.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashotpCancle.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashotpCancle.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashotpCancle.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashotpCancle.FillColor = Color.Red;
            buttonBkashotpCancle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashotpCancle.ForeColor = Color.White;
            buttonBkashotpCancle.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashotpCancle.Location = new Point(675, 248);
            buttonBkashotpCancle.Name = "buttonBkashotpCancle";
            buttonBkashotpCancle.ShadowDecoration.CustomizableEdges = customizableEdges4;
            buttonBkashotpCancle.Size = new Size(84, 26);
            buttonBkashotpCancle.TabIndex = 29;
            buttonBkashotpCancle.Text = "Cancle";
            buttonBkashotpCancle.Click += buttonBkashotpCancle_Click;
            // 
            // buttonBkashotpConfirm
            // 
            buttonBkashotpConfirm.BorderColor = Color.Transparent;
            buttonBkashotpConfirm.CustomizableEdges = customizableEdges5;
            buttonBkashotpConfirm.DisabledState.BorderColor = Color.DarkGray;
            buttonBkashotpConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            buttonBkashotpConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            buttonBkashotpConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            buttonBkashotpConfirm.FillColor = Color.FromArgb(128, 128, 255);
            buttonBkashotpConfirm.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBkashotpConfirm.ForeColor = Color.White;
            buttonBkashotpConfirm.HoverState.ForeColor = Color.FromArgb(0, 192, 0);
            buttonBkashotpConfirm.Location = new Point(522, 248);
            buttonBkashotpConfirm.Name = "buttonBkashotpConfirm";
            buttonBkashotpConfirm.ShadowDecoration.CustomizableEdges = customizableEdges6;
            buttonBkashotpConfirm.Size = new Size(101, 26);
            buttonBkashotpConfirm.TabIndex = 28;
            buttonBkashotpConfirm.Text = "Comfirm";
            buttonBkashotpConfirm.Click += buttonBkashotpConfirm_Click;
            // 
            // bk
            // 
            bk.BorderThickness = 0;
            bk.CustomizableEdges = customizableEdges7;
            bk.DefaultText = "";
            bk.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            bk.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            bk.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            bk.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            bk.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            bk.Font = new Font("Segoe UI", 9F);
            bk.ForeColor = Color.Blue;
            bk.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            bk.Location = new Point(522, 140);
            bk.Name = "bk";
            bk.PasswordChar = '\0';
            bk.PlaceholderForeColor = Color.Blue;
            bk.PlaceholderText = "      ---------";
            bk.SelectedText = "";
            bk.ShadowDecoration.CustomizableEdges = customizableEdges8;
            bk.ShadowDecoration.Enabled = true;
            bk.Size = new Size(237, 26);
            bk.TabIndex = 27;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(50, 81);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(313, 265);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 26;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MediumSeaGreen;
            label1.Location = new Point(522, 60);
            label1.Name = "label1";
            label1.Size = new Size(143, 37);
            label1.TabIndex = 25;
            label1.Text = "Enter OTP";
            // 
            // Botp
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.Pink;
            ClientSize = new Size(934, 481);
            Controls.Add(buttonBkashOtpBack);
            Controls.Add(buttonBkashotpCancle);
            Controls.Add(buttonBkashotpConfirm);
            Controls.Add(bk);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Botp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Botp";
            Load += Botp_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button buttonBkashOtpBack;
        private Guna.UI2.WinForms.Guna2Button buttonBkashotpCancle;
        private Guna.UI2.WinForms.Guna2Button buttonBkashotpConfirm;
        private Guna.UI2.WinForms.Guna2TextBox bk;
        private PictureBox pictureBox1;
        private Label label1;
    }
}